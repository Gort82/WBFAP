--------------------------------------------------------
--  DDL for Procedure AAA_UPDATE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."AAA_UPDATE" ( RELATION IN VARCHAR2, ATTR_VALUE IN INT, TUPLE_ID IN NUMBER ) IS
BEGIN
  --EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1 WHERE id =:2' USING ATTR_VALUE, TUPLE_ID;
  --EXECUTE IMMEDIATE 'EXECUTE UPDATE_ATTR_AT (''COVERTYPE_A'',''LLP'', 7, 2186)';

  EXECUTE IMMEDIATE 'call UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '||ATTR_VALUE||', '||TUPLE_ID||')';

END AAA_UPDATE;

/
--------------------------------------------------------
--  DDL for Procedure ATTACK_SUPERSET
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."ATTACK_SUPERSET" (NO_TUPLES IN NUMBER, RELATION IN VARCHAR2) AS 
BEGIN
  FOR i IN 1..NO_TUPLES
  LOOP
     EXECUTE IMMEDIATE 'CALL INSERT_TUPLE('''||RELATION||''')';
  END LOOP;
  COMMIT;
END ATTACK_SUPERSET;

/
--------------------------------------------------------
--  DDL for Procedure CHECK_COMPLEX_VPK_SCHEMES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."CHECK_COMPLEX_VPK_SCHEMES" (ATTR_TO IN VARCHAR2) IS
    id_cursor sys_refcursor;
    vpk_value INT;
    group_size INT;

BEGIN
    --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT(''covertype_k'','''||ATTR_TO||''', null, 0)';
    OPEN id_cursor FOR 'SELECT LLP AS LLP, COUNT(*) AS AMOUNT FROM COVERTYPE_A WHERE LLP = LLP_RESP GROUP BY LLP HAVING COUNT(*)>1 ORDER BY LLP';

    LOOP
        FETCH id_cursor INTO vpk_value, group_size;
        EXIT WHEN id_cursor%NOTFOUND;
        EXECUTE IMMEDIATE 'UPDATE covertype_k SET '||ATTR_TO||'=:1 WHERE vpk_value =:2' USING group_size, vpk_value;



    END LOOP;
    CLOSE id_cursor;
END CHECK_COMPLEX_VPK_SCHEMES;

/
--------------------------------------------------------
--  DDL for Procedure ERASE_TUPLES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."ERASE_TUPLES" (RELATION IN VARCHAR2, IDS IN VARCHAR2) IS 
BEGIN
    --EXECUTE IMMEDIATE 'DELETE FROM '||RELATION||' WHERE ID IN '||IDS;
    EXECUTE IMMEDIATE 'DELETE FROM '||RELATION||' WHERE ID = '||IDS;
END ERASE_TUPLES;

/
--------------------------------------------------------
--  DDL for Procedure FILL_2004_ZHANG_TABLE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."FILL_2004_ZHANG_TABLE" IS 
BEGIN
  FOR i IN 1..192 LOOP
    INSERT INTO "SYSTEM"."ZHANG_A" (
      ATTR_001, ATTR_002, ATTR_003, ATTR_004, ATTR_005, ATTR_006, ATTR_007, ATTR_008, ATTR_009, ATTR_010,
      ATTR_011, ATTR_012, ATTR_013, ATTR_014, ATTR_015, ATTR_016, ATTR_017, ATTR_018, ATTR_019, ATTR_020,
      ATTR_021, ATTR_022, ATTR_023, ATTR_024, ATTR_025, ATTR_026, ATTR_027, ATTR_028, ATTR_029, ATTR_030,
      ATTR_031, ATTR_032, ATTR_033, ATTR_034, ATTR_035, ATTR_036, ATTR_037, ATTR_038, ATTR_039, ATTR_040,
      ATTR_041, ATTR_042, ATTR_043, ATTR_044, ATTR_045, ATTR_046, ATTR_047, ATTR_048, ATTR_049, ATTR_050,
      ATTR_051, ATTR_052, ATTR_053, ATTR_054, ATTR_055, ATTR_056, ATTR_057, ATTR_058, ATTR_059, ATTR_060,
      ATTR_061, ATTR_062, ATTR_063, ATTR_064, ATTR_065, ATTR_066, ATTR_067, ATTR_068, ATTR_069, ATTR_070,
      ATTR_071, ATTR_072, ATTR_073, ATTR_074, ATTR_075, ATTR_076, ATTR_077, ATTR_078, ATTR_079, ATTR_080,
      ATTR_081, ATTR_082, ATTR_083, ATTR_084, ATTR_085, ATTR_086, ATTR_087, ATTR_088, ATTR_089, ATTR_090,
      ATTR_091, ATTR_092, ATTR_093, ATTR_094, ATTR_095, ATTR_096, ATTR_097, ATTR_098, ATTR_099, ATTR_100,

      ATTR_101, ATTR_102, ATTR_103, ATTR_104, ATTR_105, ATTR_106, ATTR_107, ATTR_108, ATTR_109, ATTR_110,
      ATTR_111, ATTR_112, ATTR_113, ATTR_114, ATTR_115, ATTR_116, ATTR_117, ATTR_118, ATTR_119, ATTR_120,
      ATTR_121, ATTR_122, ATTR_123, ATTR_124, ATTR_125, ATTR_126, ATTR_127, ATTR_128, ATTR_129, ATTR_130,
      ATTR_131, ATTR_132, ATTR_133, ATTR_134, ATTR_135, ATTR_136, ATTR_137, ATTR_138, ATTR_139, ATTR_140,
      ATTR_141, ATTR_142, ATTR_143, ATTR_144, ATTR_145, ATTR_146, ATTR_147, ATTR_148, ATTR_149, ATTR_150,
      ATTR_151, ATTR_152, ATTR_153, ATTR_154, ATTR_155, ATTR_156, ATTR_157, ATTR_158, ATTR_159, ATTR_160,
      ATTR_161, ATTR_162, ATTR_163, ATTR_164, ATTR_165, ATTR_166, ATTR_167, ATTR_168, ATTR_169, ATTR_170,
      ATTR_171, ATTR_172, ATTR_173, ATTR_174, ATTR_175, ATTR_176, ATTR_177, ATTR_178, ATTR_179, ATTR_180,
      ATTR_181, ATTR_182, ATTR_183, ATTR_184, ATTR_185, ATTR_186, ATTR_187, ATTR_188, ATTR_189, ATTR_190,
      ATTR_191, ATTR_192
    ) VALUES ( 
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))),
      trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))), trunc(dbms_random.value(1,10000),trunc(dbms_random.value(2,5))));

    END LOOP;
    COMMIT;
END FILL_2004_ZHANG_TABLE;



/
--------------------------------------------------------
--  DDL for Procedure FILL_VPK_VALUES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."FILL_VPK_VALUES" IS
    id_cursor sys_refcursor;
    vpk_val INT;
BEGIN
    OPEN id_cursor FOR 'SELECT LLP AS VPK_VALUE FROM COVERTYPE_A GROUP BY LLP HAVING COUNT(*)>1 ORDER BY LLP';
    LOOP
        FETCH id_cursor INTO vpk_val;
        EXIT WHEN id_cursor%NOTFOUND;

        --INSERT INTO covertype_k (VPK_VALUE, ATTR_01, ATTR_02, ATTR_03, ATTR_04, ATTR_05, ATTR_06, ATTR_07, ATTR_08, ATTR_09, ATTR_10)
        --VALUES (vpk_val, null, null, null, null, null, null, null, null, null, null);

        INSERT INTO covertype_k (VPK_VALUE) VALUES (vpk_val);


    END LOOP;
    CLOSE id_cursor;
END FILL_VPK_VALUES;

/
--------------------------------------------------------
--  DDL for Procedure GENERATE_M
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."GENERATE_M" ( RELATION IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT, CANT_ATTR IN INT,PRIV_KEY IN VARCHAR2) IS
    id_cursor sys_refcursor;
    id_row NUMBER;
    attr_01 INT;
    attr_02 INT;
    attr_03 INT;
    attr_04 INT;
    attr_05 INT;
    attr_06 INT;
    attr_07 INT;
    attr_08 INT;
    attr_09 INT;
    attr_10 INT;
    value_row INT;
    concatenated_value VARCHAR2(80);
    row_collector NUMBER_ARRAY;
    row_counter NUMBER_ARRAY;
    temp_item INT;
    l_idx int;
    item_incremented INT;
    compared_item INT;
    skip_key int;
    item_deleted int;


    val_01 INT;
    val_02 INT;
    val_03 INT;
    val_04 INT;
    val_05 INT;
    val_06 INT;
    val_07 INT;
    val_08 INT;
    val_09 INT;
    val_10 INT;



BEGIN

    val_01 := 0;
    val_02 := 0;
    val_03 := 0;
    val_04 := 0;
    val_05 := 0;
    val_06 := 0;
    val_07 := 0;
    val_08 := 0;
    val_09 := 0;
    val_10 := 0;

    item_deleted:= 10;

    row_collector := NUMBER_ARRAY();
    row_collector.EXTEND(10);

    row_counter := NUMBER_ARRAY();
    row_counter.EXTEND(10);

    FOR i IN 1..10 LOOP
            row_counter(i):=0;
    END LOOP;

    --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '''', 0)';
    EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', '''', 0)';

    OPEN id_cursor FOR 
    'SELECT ID AS IDENT,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION              )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS ELEV_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT                 )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS ASP_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE                  )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS SLOP_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY  )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTH_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS VDTH_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS   )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTR_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM          )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDIX_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON         )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDN_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM          )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDIII_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTFP_VALUE


     FROM '||RELATION ||' 

     WHERE  LENGTH(num_to_bin(ELEVATION              )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(ASPECT                 )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND
            LENGTH(num_to_bin(SLOPE                  )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY  )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND
            LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS   )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_9AM          )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(HILLSHADE_NOON         )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_3PM          )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT ||'+'||LSB_COUNT;

    LOOP
        FETCH id_cursor INTO id_row, attr_01, attr_02, attr_03, attr_04, attr_05, attr_06, attr_07, attr_08, attr_09, attr_10;
        EXIT WHEN id_cursor%NOTFOUND;

        row_collector(1):= attr_01;
        row_collector(2):= attr_02;
        row_collector(3):= attr_03;
        row_collector(4):= attr_04;
        row_collector(5):= attr_05;
        row_collector(6):= attr_06;
        row_collector(7):= attr_07;
        row_collector(8):= attr_08;
        row_collector(9):= attr_09;
        row_collector(10):= attr_10;

        --dbms_output.put_line('ANTES');
        --FOR i IN 1..10 LOOP
        --    dbms_output.put_line(row_collector(i));
        --END LOOP;

        -------- SELECT CAST (MULTISET(SELECT * FROM TABLE (row_collector) ORDER BY 1) AS NUMBER_ARRAY) INTO row_collector FROM dual;

        skip_key := 0;

       -- dbms_output.put_line('ID:' || id_row);

        FOR i IN 1..CANT_ATTR LOOP
            item_incremented := i;
            compared_item :=  row_collector(i);
                FOR j IN i+1..10 LOOP
                    IF compared_item > row_collector(j) THEN
                        item_incremented := j;
                        compared_item := row_collector(j);
                    END IF;
                END LOOP;
            temp_item := row_collector(i);
            row_collector(i) := row_collector(item_incremented);
            row_collector(item_incremented) := temp_item;

            row_counter(item_incremented):= row_counter(item_incremented)+1;

           -- dbms_output.put_line(item_incremented);

            IF item_deleted = item_incremented THEN
            --IF item_incremented = 1 OR item_incremented = 2 OR item_incremented = 3 OR item_incremented = 4  OR item_incremented = 5 THEN
               skip_key := 1;
            end if;
        END LOOP;

        --dbms_output.put_line('DESP');
        --FOR i IN 1..10 LOOP
        --    dbms_output.put_line(row_collector(i));
        --END LOOP;

        -- dbms_output.put_line('FINN');

        FOR i IN 1..CANT_ATTR LOOP
            concatenated_value := concatenated_value || TO_CHAR(num_to_bin(row_collector(i)));
        END LOOP;

        -- dbms_output.put_line(concatenated_value);
        --dbms_output.put_line(BINARY_CHAR_TO_INTEGER(concatenated_value));

        value_row:= BINARY_CHAR_TO_INTEGER(concatenated_value);

        --dbms_output.put_line(concatenated_value);
        --dbms_output.put_line(value_row);

       --dbms_output.put_line(value_row);
       --dbms_output.put_line(id_row);


       --val_01 := row_counter(1);
       --val_02 := row_counter(2);
       --val_03 := row_counter(3);
       --val_04 := row_counter(4);
       --val_05 := row_counter(5);
       --val_06 := row_counter(6);
       --val_07 := row_counter(7);
       --val_08 := row_counter(8);
       --val_09 := row_counter(9);
       --val_10 := row_counter(10);


        --EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET ''LLP'' =:1 ' USING empthy_val;

        IF skip_key = 1 THEN
             --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', null, '||id_row||')';
             EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', null, '||id_row||')';
        ELSE
             --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '||value_row||', '||id_row||')';
             EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', '||value_row||', '||id_row||')';
        END IF;



        --  EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '||value_row||', '||id_row||')';

        concatenated_value:='';

    END LOOP;


    dbms_output.put_line('CONTADOR');
    FOR i IN 1..10 LOOP
            dbms_output.put_line(row_counter(i));
    END LOOP;

    CLOSE id_cursor; 


END GENERATE_M;

/
--------------------------------------------------------
--  DDL for Procedure GENERATE_O
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."GENERATE_O" ( RELATION IN VARCHAR2, MSB_COUNT IN INT) IS
    id_cursor sys_refcursor;
    id_row NUMBER;
    value_row INT;

    max_items INT;

    attr_01 VARCHAR2(100);
    attr_02 VARCHAR2(100);
    attr_03 VARCHAR2(100);
    attr_04 VARCHAR2(100);
    attr_05 VARCHAR2(100);
    attr_06 VARCHAR2(100);
    attr_07 VARCHAR2(100);
    attr_08 VARCHAR2(100);
    attr_09 VARCHAR2(100);
    attr_10 VARCHAR2(100);

    val_01 INT;
    val_02 INT;
    val_03 INT;
    val_04 INT;
    val_05 INT;
    val_06 INT;
    val_07 INT;
    val_08 INT;
    val_09 INT;
    val_10 INT;

    attr_erased INT;
    skip_vpk INT;

BEGIN

    max_items := 11;

    attr_erased := 11;

    skip_vpk :=0;

    val_01 := 0;
    val_02 := 0;
    val_03 := 0;
    val_04 := 0;
    val_05 := 0;
    val_06 := 0;
    val_07 := 0;
    val_08 := 0;
    val_09 := 0;
    val_10 := 0;

    --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '''', 0)';
    --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', '''', 0)';
    EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''TUPL_SEED'', '''', 0)';

    OPEN id_cursor FOR 
    'SELECT ID AS IDENT, 
            BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||') || 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||') || 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || 
                                          CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||') ||
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||') || 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')) AS NEW_VAL,

                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')               AS ELEV_VALUE, 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||')                  AS ASP_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                   AS SLOP_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||')   AS HDTH_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||')  AS VDTH_VALUE, 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||')    AS HDTR_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')           AS HSDIX_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||')          AS HSDN_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')           AS HSDIII_VALUE, 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||') AS HDTFP_VALUE



    FROM '||RELATION ||' 

    WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
          LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
          LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
          LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
          LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT;







 --   OPEN id_cursor FOR 
 --   'SELECT ID AS IDENT, 
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')               AS ELEV_VALUE, 
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||')                  AS ASP_VALUE,
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                   AS SLOP_VALUE,
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||')   AS HDTH_VALUE,
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||')  AS VDTH_VALUE, 
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||')    AS HDTR_VALUE,
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')           AS HSDIX_VALUE,
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||')          AS HSDN_VALUE,
 --          CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')           AS HSDIII_VALUE, 
 --           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||') AS HDTFP_VALUE
 --                        
 --   FROM '||RELATION ||' 
 --     
 --   WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||' AND 
 --         LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
 --         LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||' AND 
 --         LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
 --         LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND 
 --         LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
 --         LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||' AND 
 --         LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
 --         LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||' AND 
 --         LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT;



   LOOP
      ------ FETCH id_cursor INTO id_row, value_row;
       FETCH id_cursor INTO id_row, value_row, attr_01, attr_02, attr_03, attr_04, attr_05, attr_06, attr_07, attr_08, attr_09, attr_10;

       ---FETCH id_cursor INTO id_row, attr_01, attr_02, attr_03, attr_04, attr_05, attr_06, attr_07, attr_08, attr_09, attr_10;
       EXIT WHEN id_cursor%NOTFOUND;

        IF attr_01 != '_' THEN val_01 := val_01 + 1; END IF;
        IF attr_02 != '_' THEN val_02 := val_02 + 1; END IF;
        IF attr_03 != '_' THEN val_03 := val_03 + 1; END IF;
        IF attr_04 != '_' THEN val_04 := val_04 + 1; END IF;
        IF attr_05 != '_' THEN val_05 := val_05 + 1; END IF;
        IF attr_06 != '_' THEN val_06 := val_06 + 1; END IF;
        IF attr_07 != '_' THEN val_07 := val_07 + 1; END IF;
        IF attr_08 != '_' THEN val_08 := val_08 + 1; END IF;
        IF attr_09 != '_' THEN val_09 := val_09 + 1; END IF;
        IF attr_10 != '_' THEN val_10 := val_10 + 1; END IF;

       --dbms_output.put_line(id_row);


       IF attr_erased = 1 AND attr_01 != '_' THEN
          skip_vpk := 1;
       ELSE 
          IF attr_erased = 2 AND attr_02 != '_' THEN
              skip_vpk := 1;
          ELSE 
              IF attr_erased = 3 AND attr_03 != '_' THEN
              --IF (attr_erased = 3 AND attr_03 != '_') OR (attr_erased = 3 AND attr_02 != '_') THEN
                  skip_vpk := 1;
              ELSE 
                  IF attr_erased = 4 AND attr_04 != '_' THEN
                      skip_vpk := 1;
                  ELSE 
                      IF attr_erased = 5 AND attr_05 != '_' THEN
                          skip_vpk := 1;
                      ELSE 
                          IF attr_erased = 6 AND attr_06 != '_' THEN
                              skip_vpk := 1;
                          ELSE 
                              IF attr_erased = 7 AND attr_07 != '_' THEN
                                  skip_vpk := 1;
                              ELSE 
                                  IF attr_erased = 8 AND attr_08 != '_' THEN
                                      skip_vpk := 1;
                                  ELSE 
                                      IF attr_erased = 9 AND attr_09 != '_' THEN
                                          skip_vpk := 1;
                                      ELSE 
                                          IF attr_erased = 10 AND attr_10 != '_' THEN
                                              skip_vpk := 1;
                                          END IF;
                                      END IF;
                                  END IF;
                              END IF;
                          END IF;
                      END IF;
                  END IF;
              END IF;
          END IF;
      END IF;

       --IF attr_01 != '_' OR attr_02 != '_'  OR attr_03 != '_' OR attr_04 != '_' OR attr_05 != '_' THEN 
       --       skip_vpk := 1;
       --END IF; 

       --IF skip_vpk = 1 THEN
         -- --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', null, '||id_row||')';
       --   EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', null, '||id_row||')';
       --ELSE
          -- --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '||value_row||', '||id_row||')';
       --   EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', '||value_row||', '||id_row||')';
       --END IF;


       IF skip_vpk = 1 THEN
          EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''TUPL_SEED'', null, '||id_row||')';
       ELSE
          EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''TUPL_SEED'', '||value_row||', '||id_row||')';
       END IF;
       skip_vpk := 0;

   END LOOP;

       dbms_output.put_line('CONTADOR');

   dbms_output.put_line(val_01);
   dbms_output.put_line(val_02);
   dbms_output.put_line(val_03);
   dbms_output.put_line(val_04);
   dbms_output.put_line(val_05);
   dbms_output.put_line(val_06);
   dbms_output.put_line(val_07);
   dbms_output.put_line(val_08);
   dbms_output.put_line(val_09);
   dbms_output.put_line(val_10);


    CLOSE id_cursor;
END GENERATE_O;

/
--------------------------------------------------------
--  DDL for Procedure GENERATE_OEXT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."GENERATE_OEXT" ( RELATION IN VARCHAR2, MSB_COUNT IN INT) IS
    id_cursor sys_refcursor;
    id_row NUMBER;
    value_row INT;

    max_items INT;
    incremento INT;

    attr_01 VARCHAR2(100);
    attr_02 VARCHAR2(100);
    attr_03 VARCHAR2(100);
    attr_04 VARCHAR2(100);
    attr_05 VARCHAR2(100);
    attr_06 VARCHAR2(100);
    attr_07 VARCHAR2(100);
    attr_08 VARCHAR2(100);
    attr_09 VARCHAR2(100);
    attr_10 VARCHAR2(100);

    val_01 INT;
    val_02 INT;
    val_03 INT;
    val_04 INT;
    val_05 INT;
    val_06 INT;
    val_07 INT;
    val_08 INT;
    val_09 INT;
    val_10 INT;

BEGIN

    max_items := 1;
    incremento := 0;



    val_01 := 0;
    val_02 := 0;
    val_03 := 0;
    val_04 := 0;
    val_05 := 0;
    val_06 := 0;
    val_07 := 0;
    val_08 := 0;
    val_09 := 0;
    val_10 := 0;

    EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''TUPL_SEED'', '''', 0)';

    OPEN id_cursor FOR 
    'SELECT ID AS IDENT, 


                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')               AS ELEV_VALUE, 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||')                  AS ASP_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                   AS SLOP_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||')   AS HDTH_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||')  AS VDTH_VALUE, 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||')    AS HDTR_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')           AS HSDIX_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||')          AS HSDN_VALUE,
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')           AS HSDIII_VALUE, 
                                           CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||') AS HDTFP_VALUE



    FROM '||RELATION ||' 

    WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
          LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
          LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
          LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
          LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||' AND 
          LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT;











   LOOP
       FETCH id_cursor INTO id_row, attr_01, attr_02, attr_03, attr_04, attr_05, attr_06, attr_07, attr_08, attr_09, attr_10;

       EXIT WHEN id_cursor%NOTFOUND;


        IF attr_01 != '_' AND incremento < max_items THEN 
            val_01 := val_01 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_02 != '_' AND incremento < max_items THEN  
            val_02 := val_02 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_03 != '_' AND incremento < max_items THEN  
            val_03 := val_03 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_04 != '_' AND incremento < max_items THEN  
            val_04 := val_04 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_05 != '_' AND incremento < max_items THEN  
            val_05 := val_05 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_06 != '_' AND incremento < max_items THEN  
            val_06 := val_06 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_07 != '_' AND incremento < max_items THEN  
            val_07 := val_07 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_08 != '_' AND incremento < max_items THEN  
            val_08 := val_08 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_09 != '_' AND incremento < max_items THEN  
            val_09 := val_09 + 1; 
            incremento := incremento + 1;
        END IF;

        IF attr_10 != '_' AND incremento < max_items THEN  
            val_10 := val_10 + 1; 
            incremento := incremento + 1;
        END IF;






      incremento := 0;

   END LOOP;

       dbms_output.put_line('CONTADOR');

   dbms_output.put_line(val_01);
   dbms_output.put_line(val_02);
   dbms_output.put_line(val_03);
   dbms_output.put_line(val_04);
   dbms_output.put_line(val_05);
   dbms_output.put_line(val_06);
   dbms_output.put_line(val_07);
   dbms_output.put_line(val_08);
   dbms_output.put_line(val_09);
   dbms_output.put_line(val_10);


    CLOSE id_cursor;
END GENERATE_OEXT;

/
--------------------------------------------------------
--  DDL for Procedure GENERATE_S_I
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."GENERATE_S_I" ( RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_RANGE IN INT ) IS
    id_cursor sys_refcursor;
    id_row NUMBER;
    value_row INT;

BEGIN
    EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '''', 0)';

    OPEN id_cursor FOR 'SELECT ID AS IDENT, BINARY_CHAR_TO_INTEGER(SUBSTR(NUM_TO_BIN(ABS('||ATTR_NAME||')),1,'||MSB_RANGE||')) AS NEW_VAL FROM '||RELATION;
    LOOP
        FETCH id_cursor INTO id_row, value_row;
        EXIT WHEN id_cursor%NOTFOUND;

        EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '||value_row||', '||id_row||')';

    END LOOP;

    CLOSE id_cursor; 


END GENERATE_S_I;

/
--------------------------------------------------------
--  DDL for Procedure INIT_SEC
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."INIT_SEC" IS
    -- CONFENIS 2019
    prev_cursor sys_refcursor;
    next_cursor sys_refcursor;
    cons_cursor sys_refcursor;

    id_row NUMBER;
    prev_vpk INT;
    curr_vpk INT;
    next_vpk INT;
    current_val INT;

    prev_val INT;
    curr_val INT;
    next_val INT;
BEGIN
    prev_vpk := -1;
    curr_vpk := -1;
    next_vpk := -1;
    current_val := -1;

    prev_val := -1;
    curr_val := -1; 
    next_val := -1;

    EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET PREV_VPK = null';
    OPEN prev_cursor FOR 'SELECT LLP AS IDENT, VPK_PERS AS VPK FROM COVERTYPE_A ORDER BY LLP';
    LOOP
       FETCH prev_cursor INTO id_row, current_val;
       EXIT WHEN prev_cursor%NOTFOUND;
       IF prev_vpk = -1 THEN
          prev_vpk := 0;
       ELSE
          prev_vpk := curr_vpk;
       END IF;
       curr_vpk := current_val;
       EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET PREV_VPK =:1 WHERE LLP =:2 ' USING prev_vpk, id_row;
   END LOOP;
   CLOSE prev_cursor;

   EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET NEXT_VPK = null';
   OPEN next_cursor FOR 'SELECT LLP AS IDENT, VPK_PERS AS VPK FROM COVERTYPE_A ORDER BY LLP DESC';
   LOOP
      FETCH next_cursor INTO id_row, current_val;
      EXIT WHEN next_cursor%NOTFOUND;
      IF next_vpk = -1 THEN
          next_vpk := 0;
      ELSE
          next_vpk := curr_vpk;
      END IF;
      curr_vpk := current_val;
      EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET NEXT_VPK =:1 WHERE LLP =:2 ' USING next_vpk, id_row;
   END LOOP;
   CLOSE next_cursor;

   EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET SEC_PERS = -1';
   OPEN cons_cursor FOR 'SELECT LLP, PREV_VPK, VPK_PERS, NEXT_VPK FROM COVERTYPE_A ORDER BY LLP';
   LOOP
       FETCH cons_cursor INTO id_row, prev_val, curr_val, next_val;
       EXIT WHEN cons_cursor%NOTFOUND;

       IF (prev_val > curr_val) AND (next_val > curr_val) THEN
          EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET SEC_PERS = 0 WHERE LLP =:1 ' USING id_row;
       ELSE
          IF (prev_val < curr_val) AND (next_val < curr_val) THEN
              EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET SEC_PERS = 1 WHERE LLP =:1 ' USING id_row;
          END IF;
       END IF; 
   END LOOP;
   CLOSE cons_cursor;

END INIT_SEC;

/
--------------------------------------------------------
--  DDL for Procedure INIT_SEC_I
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."INIT_SEC_I" IS
    -- CONFENIS 2019
    prev_cursor sys_refcursor;

    id_row NUMBER;
    prev_vpk INT;
    curr_vpk INT;
    current_val INT;

BEGIN
    prev_vpk := -1;
    curr_vpk := -1;
    current_val := -1;

    EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET PREV_VPK = null';
    OPEN prev_cursor FOR 'SELECT LLP AS IDENT, VPK_PERS AS VPK FROM COVERTYPE_A ORDER BY LLP';
    LOOP
       FETCH prev_cursor INTO id_row, current_val;
       EXIT WHEN prev_cursor%NOTFOUND;
       IF prev_vpk = -1 THEN
          prev_vpk := 0;
       ELSE
          prev_vpk := curr_vpk;
       END IF;
       curr_vpk := current_val;
       EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET PREV_VPK =:1 WHERE LLP =:2 ' USING prev_vpk, id_row;
   END LOOP;
   CLOSE prev_cursor;

END INIT_SEC_I;

/
--------------------------------------------------------
--  DDL for Procedure INIT_SEC_II
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."INIT_SEC_II" IS
    -- CONFENIS 2019
    next_cursor sys_refcursor;

    id_row NUMBER;
    curr_vpk INT;
    next_vpk INT;
    current_val INT;

BEGIN
    curr_vpk := -1;
    next_vpk := -1;
    current_val := -1;

   EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET NEXT_VPK = null';
   OPEN next_cursor FOR 'SELECT LLP AS IDENT, VPK_PERS AS VPK FROM COVERTYPE_A ORDER BY LLP DESC';
   LOOP
      FETCH next_cursor INTO id_row, current_val;
      EXIT WHEN next_cursor%NOTFOUND;
      IF next_vpk = -1 THEN
          next_vpk := 0;
      ELSE
          next_vpk := curr_vpk;
      END IF;
      curr_vpk := current_val;
      EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET NEXT_VPK =:1 WHERE LLP =:2 ' USING next_vpk, id_row;
   END LOOP;
   CLOSE next_cursor;

END INIT_SEC_II;

/
--------------------------------------------------------
--  DDL for Procedure INIT_SEC_III
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."INIT_SEC_III" IS
    -- CONFENIS 2019
    cons_cursor sys_refcursor;

    id_row NUMBER;

    prev_val INT;
    curr_val INT;
    next_val INT;
BEGIN

    prev_val := -1;
    curr_val := -1; 
    next_val := -1;

   EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET SEC_PERS = -1';
   OPEN cons_cursor FOR 'SELECT LLP, PREV_VPK, VPK_PERS, NEXT_VPK FROM COVERTYPE_A ORDER BY LLP';
   LOOP
       FETCH cons_cursor INTO id_row, prev_val, curr_val, next_val;
       EXIT WHEN cons_cursor%NOTFOUND;

       IF (prev_val > curr_val) AND (next_val > curr_val) THEN
          EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET SEC_PERS = 0 WHERE LLP =:1 ' USING id_row;
       ELSE
          IF (prev_val < curr_val) AND (next_val < curr_val) THEN
              EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET SEC_PERS = 1 WHERE LLP =:1 ' USING id_row;
          END IF;
       END IF; 
   END LOOP;
   CLOSE cons_cursor;

END INIT_SEC_III;

/
--------------------------------------------------------
--  DDL for Procedure INSERT_TUPLE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."INSERT_TUPLE" (RELATION IN VARCHAR2) IS 
  P_ELEVATION FLOAT(126); MAX_ELEVATION FLOAT(126); MIN_ELEVATION FLOAT(126);
	P_ASPECT FLOAT(126); MAX_ASPECT FLOAT(126); MIN_ASPECT FLOAT(126);
	P_SLOPE FLOAT(126); MAX_SLOPE FLOAT(126); MIN_SLOPE FLOAT(126);
	P_HOR_DIST_TO_HYDROLOGY FLOAT(126); MAX_HOR_DIST_TO_HYDROLOGY FLOAT(126); MIN_HOR_DIST_TO_HYDROLOGY FLOAT(126);
	P_VERT_DIST_TO_HYDROLOGY FLOAT(126); MAX_VERT_DIST_TO_HYDROLOGY FLOAT(126); MIN_VERT_DIST_TO_HYDROLOGY FLOAT(126);
	P_HOR_DIST_TO_ROADWAYS FLOAT(126); MAX_HOR_DIST_TO_ROADWAYS FLOAT(126); MIN_HOR_DIST_TO_ROADWAYS FLOAT(126);
	P_HILLSHADE_9AM FLOAT(126); MAX_HILLSHADE_9AM FLOAT(126); MIN_HILLSHADE_9AM FLOAT(126);
	P_HILLSHADE_NOON FLOAT(126); MAX_HILLSHADE_NOON FLOAT(126); MIN_HILLSHADE_NOON FLOAT(126);
	P_HILLSHADE_3PM FLOAT(126); MAX_HILLSHADE_3PM FLOAT(126); MIN_HILLSHADE_3PM FLOAT(126);
	P_HOR_DIST_TO_FIRE_POINTS FLOAT(126); MAX_HOR_DIST_TO_FIRE_POINTS FLOAT(126); MIN_HOR_DIST_TO_FIRE_POINTS FLOAT(126);
	P_WILDERNESS_AREA_1 NUMBER; MAX_WILDERNESS_AREA_1 NUMBER; MIN_WILDERNESS_AREA_1 NUMBER;
	P_WILDERNESS_AREA_2 NUMBER; MAX_WILDERNESS_AREA_2 NUMBER; MIN_WILDERNESS_AREA_2 NUMBER;
	P_WILDERNESS_AREA_3 NUMBER; MAX_WILDERNESS_AREA_3 NUMBER; MIN_WILDERNESS_AREA_3 NUMBER;
	P_WILDERNESS_AREA_4 NUMBER; MAX_WILDERNESS_AREA_4 NUMBER; MIN_WILDERNESS_AREA_4 NUMBER;
	P_SOIL_TYPE_01 NUMBER; MAX_SOIL_TYPE_01 NUMBER; MIN_SOIL_TYPE_01 NUMBER;
	P_SOIL_TYPE_02 NUMBER; MAX_SOIL_TYPE_02 NUMBER; MIN_SOIL_TYPE_02 NUMBER;
	P_SOIL_TYPE_03 NUMBER; MAX_SOIL_TYPE_03 NUMBER; MIN_SOIL_TYPE_03 NUMBER;
	P_SOIL_TYPE_04 NUMBER; MAX_SOIL_TYPE_04 NUMBER; MIN_SOIL_TYPE_04 NUMBER;
	P_SOIL_TYPE_05 NUMBER; MAX_SOIL_TYPE_05 NUMBER; MIN_SOIL_TYPE_05 NUMBER;
	P_SOIL_TYPE_06 NUMBER; MAX_SOIL_TYPE_06 NUMBER; MIN_SOIL_TYPE_06 NUMBER;
	P_SOIL_TYPE_07 NUMBER; MAX_SOIL_TYPE_07 NUMBER; MIN_SOIL_TYPE_07 NUMBER;
	P_SOIL_TYPE_08 NUMBER; MAX_SOIL_TYPE_08 NUMBER; MIN_SOIL_TYPE_08 NUMBER;
	P_SOIL_TYPE_09 NUMBER; MAX_SOIL_TYPE_09 NUMBER; MIN_SOIL_TYPE_09 NUMBER;
	P_SOIL_TYPE_10 NUMBER; MAX_SOIL_TYPE_10 NUMBER; MIN_SOIL_TYPE_10 NUMBER;
	P_SOIL_TYPE_11 NUMBER; MAX_SOIL_TYPE_11 NUMBER; MIN_SOIL_TYPE_11 NUMBER;
	P_SOIL_TYPE_12 NUMBER; MAX_SOIL_TYPE_12 NUMBER; MIN_SOIL_TYPE_12 NUMBER;
	P_SOIL_TYPE_13 NUMBER; MAX_SOIL_TYPE_13 NUMBER; MIN_SOIL_TYPE_13 NUMBER;
	P_SOIL_TYPE_14 NUMBER; MAX_SOIL_TYPE_14 NUMBER; MIN_SOIL_TYPE_14 NUMBER;
	P_SOIL_TYPE_15 NUMBER; MAX_SOIL_TYPE_15 NUMBER; MIN_SOIL_TYPE_15 NUMBER;
	P_SOIL_TYPE_16 NUMBER; MAX_SOIL_TYPE_16 NUMBER; MIN_SOIL_TYPE_16 NUMBER;
	P_SOIL_TYPE_17 NUMBER; MAX_SOIL_TYPE_17 NUMBER; MIN_SOIL_TYPE_17 NUMBER;
	P_SOIL_TYPE_18 NUMBER; MAX_SOIL_TYPE_18 NUMBER; MIN_SOIL_TYPE_18 NUMBER;
	P_SOIL_TYPE_19 NUMBER; MAX_SOIL_TYPE_19 NUMBER; MIN_SOIL_TYPE_19 NUMBER;
	P_SOIL_TYPE_20 NUMBER; MAX_SOIL_TYPE_20 NUMBER; MIN_SOIL_TYPE_20 NUMBER;
	P_SOIL_TYPE_21 NUMBER; MAX_SOIL_TYPE_21 NUMBER; MIN_SOIL_TYPE_21 NUMBER;
	P_SOIL_TYPE_22 NUMBER; MAX_SOIL_TYPE_22 NUMBER; MIN_SOIL_TYPE_22 NUMBER;
	P_SOIL_TYPE_23 NUMBER; MAX_SOIL_TYPE_23 NUMBER; MIN_SOIL_TYPE_23 NUMBER;
	P_SOIL_TYPE_24 NUMBER; MAX_SOIL_TYPE_24 NUMBER; MIN_SOIL_TYPE_24 NUMBER;
	P_SOIL_TYPE_25 NUMBER; MAX_SOIL_TYPE_25 NUMBER; MIN_SOIL_TYPE_25 NUMBER;
	P_SOIL_TYPE_26 NUMBER; MAX_SOIL_TYPE_26 NUMBER; MIN_SOIL_TYPE_26 NUMBER;
	P_SOIL_TYPE_27 NUMBER; MAX_SOIL_TYPE_27 NUMBER; MIN_SOIL_TYPE_27 NUMBER;
	P_SOIL_TYPE_28 NUMBER; MAX_SOIL_TYPE_28 NUMBER; MIN_SOIL_TYPE_28 NUMBER;
	P_SOIL_TYPE_29 NUMBER; MAX_SOIL_TYPE_29 NUMBER; MIN_SOIL_TYPE_29 NUMBER;
	P_SOIL_TYPE_30 NUMBER; MAX_SOIL_TYPE_30 NUMBER; MIN_SOIL_TYPE_30 NUMBER;
	P_SOIL_TYPE_31 NUMBER; MAX_SOIL_TYPE_31 NUMBER; MIN_SOIL_TYPE_31 NUMBER;
	P_SOIL_TYPE_32 NUMBER; MAX_SOIL_TYPE_32 NUMBER; MIN_SOIL_TYPE_32 NUMBER;
  P_SOIL_TYPE_33 NUMBER; MAX_SOIL_TYPE_33 NUMBER; MIN_SOIL_TYPE_33 NUMBER;
	P_SOIL_TYPE_34 NUMBER; MAX_SOIL_TYPE_34 NUMBER; MIN_SOIL_TYPE_34 NUMBER;
	P_SOIL_TYPE_35 NUMBER; MAX_SOIL_TYPE_35 NUMBER; MIN_SOIL_TYPE_35 NUMBER;
	P_SOIL_TYPE_36 NUMBER; MAX_SOIL_TYPE_36 NUMBER; MIN_SOIL_TYPE_36 NUMBER;
	P_SOIL_TYPE_37 NUMBER; MAX_SOIL_TYPE_37 NUMBER; MIN_SOIL_TYPE_37 NUMBER;
	P_SOIL_TYPE_38 NUMBER; MAX_SOIL_TYPE_38 NUMBER; MIN_SOIL_TYPE_38 NUMBER;
	P_SOIL_TYPE_39 NUMBER; MAX_SOIL_TYPE_39 NUMBER; MIN_SOIL_TYPE_39 NUMBER;
	P_SOIL_TYPE_40 NUMBER; MAX_SOIL_TYPE_40 NUMBER; MIN_SOIL_TYPE_40 NUMBER;
	P_COVER_TYPE NUMBER;  MAX_COVER_TYPE NUMBER; MIN_COVER_TYPE NUMBER;
BEGIN
  EXECUTE IMMEDIATE 'SELECT MAX(ELEVATION), MAX(ASPECT), MAX(SLOPE), MAX(HOR_DIST_TO_HYDROLOGY), MAX(VERT_DIST_TO_HYDROLOGY),  MAX(HOR_DIST_TO_ROADWAYS), MAX(HILLSHADE_9AM), MAX(HILLSHADE_NOON), MAX(HILLSHADE_3PM), MAX(HOR_DIST_TO_FIRE_POINTS), MAX(WILDERNESS_AREA_1), MAX(WILDERNESS_AREA_2), MAX(WILDERNESS_AREA_3), MAX(WILDERNESS_AREA_4), MAX(SOIL_TYPE_01), MAX(SOIL_TYPE_02), MAX(SOIL_TYPE_03), MAX(SOIL_TYPE_04), MAX(SOIL_TYPE_05), MAX(SOIL_TYPE_06), MAX(SOIL_TYPE_07), MAX(SOIL_TYPE_08), MAX(SOIL_TYPE_09), MAX(SOIL_TYPE_10), MAX(SOIL_TYPE_11), MAX(SOIL_TYPE_12), MAX(SOIL_TYPE_13), MAX(SOIL_TYPE_14), MAX(SOIL_TYPE_15), MAX(SOIL_TYPE_16), MAX(SOIL_TYPE_17), MAX(SOIL_TYPE_18), MAX(SOIL_TYPE_19), MAX(SOIL_TYPE_20), MAX(SOIL_TYPE_21), MAX(SOIL_TYPE_22), MAX(SOIL_TYPE_23), MAX(SOIL_TYPE_24), MAX(SOIL_TYPE_25), MAX(SOIL_TYPE_26), MAX(SOIL_TYPE_27), MAX(SOIL_TYPE_28), MAX(SOIL_TYPE_29), MAX(SOIL_TYPE_30), MAX(SOIL_TYPE_31), MAX(SOIL_TYPE_32), MAX(SOIL_TYPE_33), MAX(SOIL_TYPE_34), MAX(SOIL_TYPE_35), MAX(SOIL_TYPE_36), MAX(SOIL_TYPE_37), MAX(SOIL_TYPE_38), MAX(SOIL_TYPE_39), MAX(SOIL_TYPE_40), MAX(COVER_TYPE) FROM '||RELATION INTO MAX_ELEVATION, MAX_ASPECT, MAX_SLOPE, MAX_HOR_DIST_TO_HYDROLOGY, MAX_VERT_DIST_TO_HYDROLOGY, MAX_HOR_DIST_TO_ROADWAYS, MAX_HILLSHADE_9AM, MAX_HILLSHADE_NOON, MAX_HILLSHADE_3PM, MAX_HOR_DIST_TO_FIRE_POINTS, MAX_WILDERNESS_AREA_1, MAX_WILDERNESS_AREA_2, MAX_WILDERNESS_AREA_3, MAX_WILDERNESS_AREA_4, MAX_SOIL_TYPE_01, MAX_SOIL_TYPE_02, MAX_SOIL_TYPE_03, MAX_SOIL_TYPE_04, MAX_SOIL_TYPE_05, MAX_SOIL_TYPE_06, MAX_SOIL_TYPE_07, MAX_SOIL_TYPE_08, MAX_SOIL_TYPE_09, MAX_SOIL_TYPE_10, MAX_SOIL_TYPE_11, MAX_SOIL_TYPE_12, MAX_SOIL_TYPE_13, MAX_SOIL_TYPE_14, MAX_SOIL_TYPE_15, MAX_SOIL_TYPE_16, MAX_SOIL_TYPE_17, MAX_SOIL_TYPE_18, MAX_SOIL_TYPE_19, MAX_SOIL_TYPE_20, MAX_SOIL_TYPE_21, MAX_SOIL_TYPE_22, MAX_SOIL_TYPE_23, MAX_SOIL_TYPE_24, MAX_SOIL_TYPE_25, MAX_SOIL_TYPE_26, MAX_SOIL_TYPE_27, MAX_SOIL_TYPE_28, MAX_SOIL_TYPE_29, MAX_SOIL_TYPE_30, MAX_SOIL_TYPE_31, MAX_SOIL_TYPE_32, MAX_SOIL_TYPE_33, MAX_SOIL_TYPE_34, MAX_SOIL_TYPE_35, MAX_SOIL_TYPE_36, MAX_SOIL_TYPE_37, MAX_SOIL_TYPE_38, MAX_SOIL_TYPE_39, MAX_SOIL_TYPE_40, MAX_COVER_TYPE; 
  EXECUTE IMMEDIATE 'SELECT MIN(ELEVATION), MIN(ASPECT), MIN(SLOPE), MIN(HOR_DIST_TO_HYDROLOGY), MIN(VERT_DIST_TO_HYDROLOGY),  MIN(HOR_DIST_TO_ROADWAYS), MIN(HILLSHADE_9AM), MIN(HILLSHADE_NOON), MIN(HILLSHADE_3PM), MIN(HOR_DIST_TO_FIRE_POINTS), MIN(WILDERNESS_AREA_1), MIN(WILDERNESS_AREA_2), MIN(WILDERNESS_AREA_3), MIN(WILDERNESS_AREA_4), MIN(SOIL_TYPE_01), MIN(SOIL_TYPE_02), MIN(SOIL_TYPE_03), MIN(SOIL_TYPE_04), MIN(SOIL_TYPE_05), MIN(SOIL_TYPE_06), MIN(SOIL_TYPE_07), MIN(SOIL_TYPE_08), MIN(SOIL_TYPE_09), MIN(SOIL_TYPE_10), MIN(SOIL_TYPE_11), MIN(SOIL_TYPE_12), MIN(SOIL_TYPE_13), MIN(SOIL_TYPE_14), MIN(SOIL_TYPE_15), MIN(SOIL_TYPE_16), MIN(SOIL_TYPE_17), MIN(SOIL_TYPE_18), MIN(SOIL_TYPE_19), MIN(SOIL_TYPE_20), MIN(SOIL_TYPE_21), MIN(SOIL_TYPE_22), MIN(SOIL_TYPE_23), MIN(SOIL_TYPE_24), MIN(SOIL_TYPE_25), MIN(SOIL_TYPE_26), MIN(SOIL_TYPE_27), MIN(SOIL_TYPE_28), MIN(SOIL_TYPE_29), MIN(SOIL_TYPE_30), MIN(SOIL_TYPE_31), MIN(SOIL_TYPE_32), MIN(SOIL_TYPE_33), MIN(SOIL_TYPE_34), MIN(SOIL_TYPE_35), MIN(SOIL_TYPE_36), MIN(SOIL_TYPE_37), MIN(SOIL_TYPE_38), MIN(SOIL_TYPE_39), MIN(SOIL_TYPE_40), MIN(COVER_TYPE) FROM '||RELATION INTO MIN_ELEVATION, MIN_ASPECT, MIN_SLOPE, MIN_HOR_DIST_TO_HYDROLOGY, MIN_VERT_DIST_TO_HYDROLOGY, MIN_HOR_DIST_TO_ROADWAYS, MIN_HILLSHADE_9AM, MIN_HILLSHADE_NOON, MIN_HILLSHADE_3PM, MIN_HOR_DIST_TO_FIRE_POINTS, MIN_WILDERNESS_AREA_1, MIN_WILDERNESS_AREA_2, MIN_WILDERNESS_AREA_3, MIN_WILDERNESS_AREA_4, MIN_SOIL_TYPE_01, MIN_SOIL_TYPE_02, MIN_SOIL_TYPE_03, MIN_SOIL_TYPE_04, MIN_SOIL_TYPE_05, MIN_SOIL_TYPE_06, MIN_SOIL_TYPE_07, MIN_SOIL_TYPE_08, MIN_SOIL_TYPE_09, MIN_SOIL_TYPE_10, MIN_SOIL_TYPE_11, MIN_SOIL_TYPE_12, MIN_SOIL_TYPE_13, MIN_SOIL_TYPE_14, MIN_SOIL_TYPE_15, MIN_SOIL_TYPE_16, MIN_SOIL_TYPE_17, MIN_SOIL_TYPE_18, MIN_SOIL_TYPE_19, MIN_SOIL_TYPE_20, MIN_SOIL_TYPE_21, MIN_SOIL_TYPE_22, MIN_SOIL_TYPE_23, MIN_SOIL_TYPE_24, MIN_SOIL_TYPE_25, MIN_SOIL_TYPE_26, MIN_SOIL_TYPE_27, MIN_SOIL_TYPE_28, MIN_SOIL_TYPE_29, MIN_SOIL_TYPE_30, MIN_SOIL_TYPE_31, MIN_SOIL_TYPE_32, MIN_SOIL_TYPE_33, MIN_SOIL_TYPE_34, MIN_SOIL_TYPE_35, MIN_SOIL_TYPE_36, MIN_SOIL_TYPE_37, MIN_SOIL_TYPE_38, MIN_SOIL_TYPE_39, MIN_SOIL_TYPE_40, MIN_COVER_TYPE; 

  SELECT round(dbms_random.value(MIN_ELEVATION,MAX_ELEVATION)) INTO P_ELEVATION from dual;
  SELECT round(dbms_random.value(MIN_ASPECT,MAX_ASPECT)) INTO P_ASPECT from dual;
  SELECT round(dbms_random.value(MIN_SLOPE,MAX_SLOPE)) INTO P_SLOPE from dual;
  SELECT round(dbms_random.value(MIN_HOR_DIST_TO_HYDROLOGY,MAX_HOR_DIST_TO_HYDROLOGY)) INTO P_HOR_DIST_TO_HYDROLOGY from dual;
  SELECT round(dbms_random.value(MIN_VERT_DIST_TO_HYDROLOGY,MAX_VERT_DIST_TO_HYDROLOGY)) INTO P_VERT_DIST_TO_HYDROLOGY from dual;
  SELECT round(dbms_random.value(MIN_HOR_DIST_TO_ROADWAYS,MAX_HOR_DIST_TO_ROADWAYS)) INTO P_HOR_DIST_TO_ROADWAYS from dual;
  SELECT round(dbms_random.value(MIN_HILLSHADE_9AM,MAX_HILLSHADE_9AM)) INTO P_HILLSHADE_9AM from dual;
  SELECT round(dbms_random.value(MIN_HILLSHADE_NOON,MAX_HILLSHADE_NOON)) INTO P_HILLSHADE_NOON from dual;
  SELECT round(dbms_random.value(MIN_HILLSHADE_3PM,MAX_HILLSHADE_3PM)) INTO P_HILLSHADE_3PM from dual;
  SELECT round(dbms_random.value(MIN_HOR_DIST_TO_FIRE_POINTS,MAX_HOR_DIST_TO_FIRE_POINTS)) INTO P_HOR_DIST_TO_FIRE_POINTS from dual;
  SELECT round(dbms_random.value(MIN_WILDERNESS_AREA_1,MAX_WILDERNESS_AREA_1)) INTO P_WILDERNESS_AREA_1 from dual;
  SELECT round(dbms_random.value(MIN_WILDERNESS_AREA_2,MAX_WILDERNESS_AREA_2)) INTO P_WILDERNESS_AREA_2 from dual;
  SELECT round(dbms_random.value(MIN_WILDERNESS_AREA_3,MAX_WILDERNESS_AREA_3)) INTO P_WILDERNESS_AREA_3 from dual;
  SELECT round(dbms_random.value(MIN_WILDERNESS_AREA_4,MAX_WILDERNESS_AREA_4)) INTO P_WILDERNESS_AREA_4 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_01,MAX_SOIL_TYPE_01)) INTO P_SOIL_TYPE_01 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_02,MAX_SOIL_TYPE_02)) INTO P_SOIL_TYPE_02 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_03,MAX_SOIL_TYPE_03)) INTO P_SOIL_TYPE_03 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_04,MAX_SOIL_TYPE_04)) INTO P_SOIL_TYPE_04 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_05,MAX_SOIL_TYPE_05)) INTO P_SOIL_TYPE_05 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_06,MAX_SOIL_TYPE_06)) INTO P_SOIL_TYPE_06 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_07,MAX_SOIL_TYPE_07)) INTO P_SOIL_TYPE_07 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_08,MAX_SOIL_TYPE_08)) INTO P_SOIL_TYPE_08 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_09,MAX_SOIL_TYPE_09)) INTO P_SOIL_TYPE_09 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_10,MAX_SOIL_TYPE_10)) INTO P_SOIL_TYPE_10 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_11,MAX_SOIL_TYPE_11)) INTO P_SOIL_TYPE_11 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_12,MAX_SOIL_TYPE_12)) INTO P_SOIL_TYPE_12 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_13,MAX_SOIL_TYPE_13)) INTO P_SOIL_TYPE_13 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_14,MAX_SOIL_TYPE_14)) INTO P_SOIL_TYPE_14 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_15,MAX_SOIL_TYPE_15)) INTO P_SOIL_TYPE_15 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_16,MAX_SOIL_TYPE_16)) INTO P_SOIL_TYPE_16 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_17,MAX_SOIL_TYPE_17)) INTO P_SOIL_TYPE_17 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_18,MAX_SOIL_TYPE_18)) INTO P_SOIL_TYPE_18 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_19,MAX_SOIL_TYPE_19)) INTO P_SOIL_TYPE_19 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_20,MAX_SOIL_TYPE_20)) INTO P_SOIL_TYPE_20 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_21,MAX_SOIL_TYPE_21)) INTO P_SOIL_TYPE_21 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_22,MAX_SOIL_TYPE_22)) INTO P_SOIL_TYPE_22 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_23,MAX_SOIL_TYPE_23)) INTO P_SOIL_TYPE_23 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_24,MAX_SOIL_TYPE_24)) INTO P_SOIL_TYPE_24 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_25,MAX_SOIL_TYPE_25)) INTO P_SOIL_TYPE_25 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_26,MAX_SOIL_TYPE_26)) INTO P_SOIL_TYPE_26 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_27,MAX_SOIL_TYPE_27)) INTO P_SOIL_TYPE_27 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_28,MAX_SOIL_TYPE_28)) INTO P_SOIL_TYPE_28 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_29,MAX_SOIL_TYPE_29)) INTO P_SOIL_TYPE_29 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_30,MAX_SOIL_TYPE_30)) INTO P_SOIL_TYPE_30 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_31,MAX_SOIL_TYPE_31)) INTO P_SOIL_TYPE_31 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_32,MAX_SOIL_TYPE_32)) INTO P_SOIL_TYPE_32 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_33,MAX_SOIL_TYPE_33)) INTO P_SOIL_TYPE_33 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_34,MAX_SOIL_TYPE_34)) INTO P_SOIL_TYPE_34 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_35,MAX_SOIL_TYPE_35)) INTO P_SOIL_TYPE_35 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_36,MAX_SOIL_TYPE_36)) INTO P_SOIL_TYPE_36 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_37,MAX_SOIL_TYPE_37)) INTO P_SOIL_TYPE_37 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_38,MAX_SOIL_TYPE_38)) INTO P_SOIL_TYPE_38 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_39,MAX_SOIL_TYPE_39)) INTO P_SOIL_TYPE_39 from dual;
  SELECT round(dbms_random.value(MIN_SOIL_TYPE_40,MAX_SOIL_TYPE_40)) INTO P_SOIL_TYPE_40 from dual;
  SELECT round(dbms_random.value(MIN_COVER_TYPE,MAX_COVER_TYPE)) INTO P_COVER_TYPE from dual;

  EXECUTE IMMEDIATE 'INSERT INTO '||RELATION||' (ELEVATION, ASPECT, SLOPE, HOR_DIST_TO_HYDROLOGY, VERT_DIST_TO_HYDROLOGY, HOR_DIST_TO_ROADWAYS, HILLSHADE_9AM, HILLSHADE_NOON, HILLSHADE_3PM, HOR_DIST_TO_FIRE_POINTS, WILDERNESS_AREA_1, WILDERNESS_AREA_2, WILDERNESS_AREA_3, WILDERNESS_AREA_4, SOIL_TYPE_01, SOIL_TYPE_02, SOIL_TYPE_03, SOIL_TYPE_04, SOIL_TYPE_05, SOIL_TYPE_06, SOIL_TYPE_07, SOIL_TYPE_08, SOIL_TYPE_09, SOIL_TYPE_10, SOIL_TYPE_11, SOIL_TYPE_12, SOIL_TYPE_13, SOIL_TYPE_14, SOIL_TYPE_15, SOIL_TYPE_16, SOIL_TYPE_17, SOIL_TYPE_18, SOIL_TYPE_19, SOIL_TYPE_20, SOIL_TYPE_21, SOIL_TYPE_22, SOIL_TYPE_23, SOIL_TYPE_24, SOIL_TYPE_25, SOIL_TYPE_26, SOIL_TYPE_27, SOIL_TYPE_28, SOIL_TYPE_29, SOIL_TYPE_30, SOIL_TYPE_31, SOIL_TYPE_32, SOIL_TYPE_33, SOIL_TYPE_34, SOIL_TYPE_35, SOIL_TYPE_36, SOIL_TYPE_37, SOIL_TYPE_38, SOIL_TYPE_39, SOIL_TYPE_40, COVER_TYPE) VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19,:20,:21,:22,:23,:24,:25,:26,:27,:28,:29,:30,:31,:32,:33,:34,:35,:36,:37,:38,:39,:40,:41,:42,:43,:44,:45,:46,:47,:48,:49,:50,:51,:52,:53,:54,:55)' USING P_ELEVATION, P_ASPECT, P_SLOPE, P_HOR_DIST_TO_HYDROLOGY, P_VERT_DIST_TO_HYDROLOGY, P_HOR_DIST_TO_ROADWAYS, P_HILLSHADE_9AM, P_HILLSHADE_NOON, P_HILLSHADE_3PM, P_HOR_DIST_TO_FIRE_POINTS, P_WILDERNESS_AREA_1, P_WILDERNESS_AREA_2, P_WILDERNESS_AREA_3, P_WILDERNESS_AREA_4, P_SOIL_TYPE_01, P_SOIL_TYPE_02, P_SOIL_TYPE_03, P_SOIL_TYPE_04, P_SOIL_TYPE_05, P_SOIL_TYPE_06, P_SOIL_TYPE_07, P_SOIL_TYPE_08, P_SOIL_TYPE_09, P_SOIL_TYPE_10, P_SOIL_TYPE_11, P_SOIL_TYPE_12, P_SOIL_TYPE_13, P_SOIL_TYPE_14, P_SOIL_TYPE_15, P_SOIL_TYPE_16, P_SOIL_TYPE_17, P_SOIL_TYPE_18, P_SOIL_TYPE_19, P_SOIL_TYPE_20, P_SOIL_TYPE_21, P_SOIL_TYPE_22, P_SOIL_TYPE_23, P_SOIL_TYPE_24, P_SOIL_TYPE_25, P_SOIL_TYPE_26, P_SOIL_TYPE_27, P_SOIL_TYPE_28, P_SOIL_TYPE_29, P_SOIL_TYPE_30, P_SOIL_TYPE_31, P_SOIL_TYPE_32, P_SOIL_TYPE_33, P_SOIL_TYPE_34, P_SOIL_TYPE_35, P_SOIL_TYPE_36, P_SOIL_TYPE_37, P_SOIL_TYPE_38, P_SOIL_TYPE_39, P_SOIL_TYPE_40, P_COVER_TYPE;

END INSERT_TUPLE;

/
--------------------------------------------------------
--  DDL for Procedure INSERT_VITAUL
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."INSERT_VITAUL" IS
    row_collector NUMBER_ARRAY;
    j int;
BEGIN
    j:=300000;

    row_collector := NUMBER_ARRAY();
    row_collector.EXTEND(1000);

    row_collector(1):=	0;
    row_collector(2):=	1;
    row_collector(3):=	3;
row_collector(4):=	4;
row_collector(5):=	5;
row_collector(6):=	7;
row_collector(7):=	8;
row_collector(8):=	9;
row_collector(9):=	11;
row_collector(10):=	12;
row_collector(11):=	13;
row_collector(12):=	15;
row_collector(13):=	17;
row_collector(14):=	19;
row_collector(15):=	21;
row_collector(16):=	23;
row_collector(17):=	24;
row_collector(18):=	25;
row_collector(19):=	27;
row_collector(20):=	28;
row_collector(21):=	29;
row_collector(22):=	31;
row_collector(23):=	35;
row_collector(24):=	36;
row_collector(25):=	37;
row_collector(26):=	39;
row_collector(27):=	43;
row_collector(28):=	44;
row_collector(29):=	45;
row_collector(30):=	47;
row_collector(31):=	51;
row_collector(32):=	53;
row_collector(33):=	55;
row_collector(34):=	56;
row_collector(35):=	59;
row_collector(36):=	60;
row_collector(37):=	61;
row_collector(38):=	63;
row_collector(39):=	68;
row_collector(40):=	69;
row_collector(41):=	71;
row_collector(42):=	72;
row_collector(43):=	73;
row_collector(44):=	75;
row_collector(45):=	76;
row_collector(46):=	77;
row_collector(47):=	79;
row_collector(48):=	87;
row_collector(49):=	88;
row_collector(50):=	89;
row_collector(51):=	91;
row_collector(52):=	92;
row_collector(53):=	93;
row_collector(54):=	95;
row_collector(55):=	99;
row_collector(56):=	100;
row_collector(57):=	101;
row_collector(58):=	103;
row_collector(59):=	108;
row_collector(60):=	109;
row_collector(61):=	111;
row_collector(62):=	115;
row_collector(63):=	117;
row_collector(64):=	119;
row_collector(65):=	120;
row_collector(66):=	123;
row_collector(67):=	124;
row_collector(68):=	125;
row_collector(69):=	127;
row_collector(70):=	136;
row_collector(71):=	137;
row_collector(72):=	139;
row_collector(73):=	140;
row_collector(74):=	141;
row_collector(75):=	143;
row_collector(76):=	147;
row_collector(77):=	149;
row_collector(78):=	151;
row_collector(79):=	152;
row_collector(80):=	155;
row_collector(81):=	156;
row_collector(82):=	157;
row_collector(83):=	159;
row_collector(84):=	172;
row_collector(85):=	173;
row_collector(86):=	175;
row_collector(87):=	177;
row_collector(88):=	179;
row_collector(89):=	181;
row_collector(90):=	183;
row_collector(91):=	184;
row_collector(92):=	185;
row_collector(93):=	187;
row_collector(94):=	188;
row_collector(95):=	189;
row_collector(96):=	191;
row_collector(97):=	196;
row_collector(98):=	199;
row_collector(99):=	200;
row_collector(100):=	201;
row_collector(101):=	204;
row_collector(102):=	205;
row_collector(103):=	207;
row_collector(104):=	216;
row_collector(105):=	219;
row_collector(106):=	220;
row_collector(107):=	221;
row_collector(108):=	223;
row_collector(109):=	228;
row_collector(110):=	229;
row_collector(111):=	231;
row_collector(112):=	236;
row_collector(113):=	237;
row_collector(114):=	239;
row_collector(115):=	245;
row_collector(116):=	247;
row_collector(117):=	248;
row_collector(118):=	252;
row_collector(119):=	253;
row_collector(120):=	275;
row_collector(121):=	277;
row_collector(122):=	279;
row_collector(123):=	281;
row_collector(124):=	283;
row_collector(125):=	284;
row_collector(126):=	285;
row_collector(127):=	287;
row_collector(128):=	291;
row_collector(129):=	292;
row_collector(130):=	293;
row_collector(131):=	295;
row_collector(132):=	300;
row_collector(133):=	301;
row_collector(134):=	303;
row_collector(135):=	307;
row_collector(136):=	309;
row_collector(137):=	311;
row_collector(138):=	312;
row_collector(139):=	315;
row_collector(140):=	316;
row_collector(141):=	317;
row_collector(142):=	319;
row_collector(143):=	344;
row_collector(144):=	345;
row_collector(145):=	347;
row_collector(146):=	348;
row_collector(147):=	349;
row_collector(148):=	351;
row_collector(149):=	355;
row_collector(150):=	356;
row_collector(151):=	357;
row_collector(152):=	359;
row_collector(153):=	364;
row_collector(154):=	365;
row_collector(155):=	367;
row_collector(156):=	371;
row_collector(157):=	375;
row_collector(158):=	376;
row_collector(159):=	379;
row_collector(160):=	380;
row_collector(161):=	381;
row_collector(162):=	383;
row_collector(163):=	396;
row_collector(164):=	397;
row_collector(165):=	403;
row_collector(166):=	405;
row_collector(167):=	407;
row_collector(168):=	408;
row_collector(169):=	411;
row_collector(170):=	412;
row_collector(171):=	413;
row_collector(172):=	415;
row_collector(173):=	428;
row_collector(174):=	435;
row_collector(175):=	437;
row_collector(176):=	439;
row_collector(177):=	440;
row_collector(178):=	443;
row_collector(179):=	444;
row_collector(180):=	445;
row_collector(181):=	447;
row_collector(182):=	452;
row_collector(183):=	456;
row_collector(184):=	460;
row_collector(185):=	461;
row_collector(186):=	463;
row_collector(187):=	471;
row_collector(188):=	472;
row_collector(189):=	476;
row_collector(190):=	477;
row_collector(191):=	484;
row_collector(192):=	485;
row_collector(193):=	492;
row_collector(194):=	493;
row_collector(195):=	495;
row_collector(196):=	503;
row_collector(197):=	508;
row_collector(198):=	509;
row_collector(199):=	548;
row_collector(200):=	549;
row_collector(201):=	551;
row_collector(202):=	556;
row_collector(203):=	557;
row_collector(204):=	559;
row_collector(205):=	563;
row_collector(206):=	567;
row_collector(207):=	568;
row_collector(208):=	572;
row_collector(209):=	573;
row_collector(210):=	580;
row_collector(211):=	583;
row_collector(212):=	584;
row_collector(213):=	588;
row_collector(214):=	589;
row_collector(215):=	591;
row_collector(216):=	599;
row_collector(217):=	600;
row_collector(218):=	601;
row_collector(219):=	604;
row_collector(220):=	605;
row_collector(221):=	611;
row_collector(222):=	612;
row_collector(223):=	613;
row_collector(224):=	615;
row_collector(225):=	620;
row_collector(226):=	621;
row_collector(227):=	623;
row_collector(228):=	627;
row_collector(229):=	629;
row_collector(230):=	631;
row_collector(231):=	632;
row_collector(232):=	635;
row_collector(233):=	636;
row_collector(234):=	637;
row_collector(235):=	639;
row_collector(236):=	691;
row_collector(237):=	693;
row_collector(238):=	695;
row_collector(239):=	696;
row_collector(240):=	697;
row_collector(241):=	699;
row_collector(242):=	700;
row_collector(243):=	701;
row_collector(244):=	703;
row_collector(245):=	708;
row_collector(246):=	712;
row_collector(247):=	715;
row_collector(248):=	716;
row_collector(249):=	717;
row_collector(250):=	719;
row_collector(251):=	727;
row_collector(252):=	728;
row_collector(253):=	731;
row_collector(254):=	732;
row_collector(255):=	733;
row_collector(256):=	735;
row_collector(257):=	739;
row_collector(258):=	740;
row_collector(259):=	741;
row_collector(260):=	748;
row_collector(261):=	749;
row_collector(262):=	751;
row_collector(263):=	755;
row_collector(264):=	757;
row_collector(265):=	759;
row_collector(266):=	764;
row_collector(267):=	765;
row_collector(268):=	787;
row_collector(269):=	796;
row_collector(270):=	797;
row_collector(271):=	803;
row_collector(272):=	804;
row_collector(273):=	805;
row_collector(274):=	807;
row_collector(275):=	812;
row_collector(276):=	813;
row_collector(277):=	815;
row_collector(278):=	819;
row_collector(279):=	821;
row_collector(280):=	823;
row_collector(281):=	824;
row_collector(282):=	828;
row_collector(283):=	829;
row_collector(284):=	856;
row_collector(285):=	861;
row_collector(286):=	868;
row_collector(287):=	869;
row_collector(288):=	871;
row_collector(289):=	876;
row_collector(290):=	879;
row_collector(291):=	883;
row_collector(292):=	887;
row_collector(293):=	888;
row_collector(294):=	892;
row_collector(295):=	893;
row_collector(296):=	909;
row_collector(297):=	917;
row_collector(298):=	925;
row_collector(299):=	947;
row_collector(300):=	949;
row_collector(301):=	951;
row_collector(302):=	956;
row_collector(303):=	957;
row_collector(304):=	959;
row_collector(305):=	964;
row_collector(306):=	968;
row_collector(307):=	972;
row_collector(308):=	973;
row_collector(309):=	984;
row_collector(310):=	988;
row_collector(311):=	989;
row_collector(312):=	991;
row_collector(313):=	996;
row_collector(314):=	1004;
row_collector(315):=	1005;
row_collector(316):=	1007;
row_collector(317):=	1020;
row_collector(318):=	1021;
row_collector(319):=	1096;
row_collector(320):=	1100;
row_collector(321):=	1101;
row_collector(322):=	1103;
row_collector(323):=	1111;
row_collector(324):=	1112;
row_collector(325):=	1113;
row_collector(326):=	1116;
row_collector(327):=	1117;
row_collector(328):=	1119;
row_collector(329):=	1124;
row_collector(330):=	1125;
row_collector(331):=	1132;
row_collector(332):=	1133;
row_collector(333):=	1139;
row_collector(334):=	1141;
row_collector(335):=	1143;
row_collector(336):=	1145;
row_collector(337):=	1148;
row_collector(338):=	1149;
row_collector(339):=	1151;
row_collector(340):=	1160;
row_collector(341):=	1164;
row_collector(342):=	1165;
row_collector(343):=	1167;
row_collector(344):=	1171;
row_collector(345):=	1173;
row_collector(346):=	1175;
row_collector(347):=	1180;
row_collector(348):=	1181;
row_collector(349):=	1183;
row_collector(350):=	1196;
row_collector(351):=	1203;
row_collector(352):=	1205;
row_collector(353):=	1207;
row_collector(354):=	1208;
row_collector(355):=	1211;
row_collector(356):=	1212;
row_collector(357):=	1213;
row_collector(358):=	1215;
row_collector(359):=	1220;
row_collector(360):=	1221;
row_collector(361):=	1224;
row_collector(362):=	1228;
row_collector(363):=	1229;
row_collector(364):=	1231;
row_collector(365):=	1239;
row_collector(366):=	1240;
row_collector(367):=	1244;
row_collector(368):=	1245;
row_collector(369):=	1247;
row_collector(370):=	1252;
row_collector(371):=	1253;
row_collector(372):=	1260;
row_collector(373):=	1261;
row_collector(374):=	1269;
row_collector(375):=	1271;
row_collector(376):=	1272;
row_collector(377):=	1276;
row_collector(378):=	1277;
row_collector(379):=	1379;
row_collector(380):=	1380;
row_collector(381):=	1381;
row_collector(382):=	1383;
row_collector(383):=	1388;
row_collector(384):=	1389;
row_collector(385):=	1391;
row_collector(386):=	1395;
row_collector(387):=	1397;
row_collector(388):=	1399;
row_collector(389):=	1400;
row_collector(390):=	1404;
row_collector(391):=	1405;
row_collector(392):=	1407;
row_collector(393):=	1416;
row_collector(394):=	1420;
row_collector(395):=	1421;
row_collector(396):=	1427;
row_collector(397):=	1429;
row_collector(398):=	1431;
row_collector(399):=	1432;
row_collector(400):=	1435;
row_collector(401):=	1436;
row_collector(402):=	1437;
row_collector(403):=	1439;
row_collector(404):=	1452;
row_collector(405):=	1459;
row_collector(406):=	1461;
row_collector(407):=	1463;
row_collector(408):=	1464;
row_collector(409):=	1467;
row_collector(410):=	1468;
row_collector(411):=	1469;
row_collector(412):=	1471;
row_collector(413):=	1476;
row_collector(414):=	1477;
row_collector(415):=	1480;
row_collector(416):=	1484;
row_collector(417):=	1485;
row_collector(418):=	1487;
row_collector(419):=	1496;
row_collector(420):=	1500;
row_collector(421):=	1501;
row_collector(422):=	1508;
row_collector(423):=	1509;
row_collector(424):=	1516;
row_collector(425):=	1517;
row_collector(426):=	1519;
row_collector(427):=	1527;
row_collector(428):=	1532;
row_collector(429):=	1533;
row_collector(430):=	1591;
row_collector(431):=	1592;
row_collector(432):=	1597;
row_collector(433):=	1604;
row_collector(434):=	1608;
row_collector(435):=	1612;
row_collector(436):=	1613;
row_collector(437):=	1615;
row_collector(438):=	1624;
row_collector(439):=	1625;
row_collector(440):=	1628;
row_collector(441):=	1629;
row_collector(442):=	1631;
row_collector(443):=	1635;
row_collector(444):=	1636;
row_collector(445):=	1637;
row_collector(446):=	1644;
row_collector(447):=	1645;
row_collector(448):=	1647;
row_collector(449):=	1651;
row_collector(450):=	1653;
row_collector(451):=	1655;
row_collector(452):=	1656;
row_collector(453):=	1660;
row_collector(454):=	1661;
row_collector(455):=	1663;
row_collector(456):=	1732;
row_collector(457):=	1736;
row_collector(458):=	1740;
row_collector(459):=	1741;
row_collector(460):=	1743;
row_collector(461):=	1751;
row_collector(462):=	1752;
row_collector(463):=	1756;
row_collector(464):=	1757;
row_collector(465):=	1763;
row_collector(466):=	1764;
row_collector(467):=	1767;
row_collector(468):=	1772;
row_collector(469):=	1773;
row_collector(470):=	1783;
row_collector(471):=	1788;
row_collector(472):=	1789;
row_collector(473):=	1821;
row_collector(474):=	1828;
row_collector(475):=	1847;
row_collector(476):=	1852;
row_collector(477):=	1853;
row_collector(478):=	1885;
row_collector(479):=	1892;
row_collector(480):=	1893;
row_collector(481):=	1895;
row_collector(482):=	1900;
row_collector(483):=	1911;
row_collector(484):=	1912;
row_collector(485):=	1916;
row_collector(486):=	1917;
row_collector(487):=	1933;
row_collector(488):=	1941;
row_collector(489):=	1949;
row_collector(490):=	1951;
row_collector(491):=	1969;
row_collector(492):=	1973;
row_collector(493):=	1976;
row_collector(494):=	1980;
row_collector(495):=	1981;
row_collector(496):=	1992;
row_collector(497):=	1997;
row_collector(498):=	2008;
row_collector(499):=	2012;
row_collector(500):=	2013;
row_collector(501):=	2020;
row_collector(502):=	2021;
row_collector(503):=	2028;
row_collector(504):=	2029;
row_collector(505):=	2039;
row_collector(506):=	2191;
row_collector(507):=	2195;
row_collector(508):=	2199;
row_collector(509):=	2200;
row_collector(510):=	2204;
row_collector(511):=	2205;
row_collector(512):=	2207;
row_collector(513):=	2227;
row_collector(514):=	2231;
row_collector(515):=	2235;
row_collector(516):=	2236;
row_collector(517):=	2237;
row_collector(518):=	2239;
row_collector(519):=	2248;
row_collector(520):=	2251;
row_collector(521):=	2252;
row_collector(522):=	2253;
row_collector(523):=	2255;
row_collector(524):=	2268;
row_collector(525):=	2269;
row_collector(526):=	2284;
row_collector(527):=	2285;
row_collector(528):=	2295;
row_collector(529):=	2299;
row_collector(530):=	2325;
row_collector(531):=	2332;
row_collector(532):=	2333;
row_collector(533):=	2339;
row_collector(534):=	2340;
row_collector(535):=	2341;
row_collector(536):=	2348;
row_collector(537):=	2355;
row_collector(538):=	2357;
row_collector(539):=	2359;
row_collector(540):=	2360;
row_collector(541):=	2363;
row_collector(542):=	2364;
row_collector(543):=	2365;
row_collector(544):=	2403;
row_collector(545):=	2404;
row_collector(546):=	2405;
row_collector(547):=	2407;
row_collector(548):=	2412;
row_collector(549):=	2424;
row_collector(550):=	2428;
row_collector(551):=	2429;
row_collector(552):=	2440;
row_collector(553):=	2445;
row_collector(554):=	2447;
row_collector(555):=	2453;
row_collector(556):=	2455;
row_collector(557):=	2456;
row_collector(558):=	2460;
row_collector(559):=	2461;
row_collector(560):=	2483;
row_collector(561):=	2485;
row_collector(562):=	2487;
row_collector(563):=	2488;
row_collector(564):=	2492;
row_collector(565):=	2493;
row_collector(566):=	2495;
row_collector(567):=	2500;
row_collector(568):=	2504;
row_collector(569):=	2508;
row_collector(570):=	2511;
row_collector(571):=	2520;
row_collector(572):=	2524;
row_collector(573):=	2525;
row_collector(574):=	2540;
row_collector(575):=	2541;
row_collector(576):=	2543;
row_collector(577):=	2549;
row_collector(578):=	2551;
row_collector(579):=	2557;
row_collector(580):=	2756;
row_collector(581):=	2760;
row_collector(582):=	2764;
row_collector(583):=	2765;
row_collector(584):=	2767;
row_collector(585):=	2776;
row_collector(586):=	2777;
row_collector(587):=	2779;
row_collector(588):=	2780;
row_collector(589):=	2781;
row_collector(590):=	2783;
row_collector(591):=	2788;
row_collector(592):=	2789;
row_collector(593):=	2796;
row_collector(594):=	2797;
row_collector(595):=	2799;
row_collector(596):=	2803;
row_collector(597):=	2807;
row_collector(598):=	2808;
row_collector(599):=	2812;
row_collector(600):=	2813;
row_collector(601):=	2844;
row_collector(602):=	2845;
row_collector(603):=	2851;
row_collector(604):=	2852;
row_collector(605):=	2853;
row_collector(606):=	2855;
row_collector(607):=	2860;
row_collector(608):=	2861;
row_collector(609):=	2863;
row_collector(610):=	2871;
row_collector(611):=	2872;
row_collector(612):=	2876;
row_collector(613):=	2877;
row_collector(614):=	2879;
row_collector(615):=	2904;
row_collector(616):=	2909;
row_collector(617):=	2915;
row_collector(618):=	2916;
row_collector(619):=	2917;
row_collector(620):=	2919;
row_collector(621):=	2924;
row_collector(622):=	2925;
row_collector(623):=	2927;
row_collector(624):=	2931;
row_collector(625):=	2935;
row_collector(626):=	2940;
row_collector(627):=	2941;
row_collector(628):=	2957;
row_collector(629):=	2965;
row_collector(630):=	2972;
row_collector(631):=	2973;
row_collector(632):=	2995;
row_collector(633):=	2997;
row_collector(634):=	2999;
row_collector(635):=	3000;
row_collector(636):=	3003;
row_collector(637):=	3004;
row_collector(638):=	3005;
row_collector(639):=	3012;
row_collector(640):=	3016;
row_collector(641):=	3020;
row_collector(642):=	3021;
row_collector(643):=	3032;
row_collector(644):=	3036;
row_collector(645):=	3037;
row_collector(646):=	3039;
row_collector(647):=	3045;
row_collector(648):=	3052;
row_collector(649):=	3053;
row_collector(650):=	3063;
row_collector(651):=	3068;
row_collector(652):=	3144;
row_collector(653):=	3149;
row_collector(654):=	3180;
row_collector(655):=	3181;
row_collector(656):=	3189;
row_collector(657):=	3196;
row_collector(658):=	3213;
row_collector(659):=	3219;
row_collector(660):=	3221;
row_collector(661):=	3223;
row_collector(662):=	3224;
row_collector(663):=	3225;
row_collector(664):=	3227;
row_collector(665):=	3228;
row_collector(666):=	3229;
row_collector(667):=	3231;
row_collector(668):=	3244;
row_collector(669):=	3251;
row_collector(670):=	3253;
row_collector(671):=	3255;
row_collector(672):=	3260;
row_collector(673):=	3261;
row_collector(674):=	3268;
row_collector(675):=	3272;
row_collector(676):=	3276;
row_collector(677):=	3277;
row_collector(678):=	3287;
row_collector(679):=	3288;
row_collector(680):=	3292;
row_collector(681):=	3293;
row_collector(682):=	3300;
row_collector(683):=	3308;
row_collector(684):=	3309;
row_collector(685):=	3311;
row_collector(686):=	3315;
row_collector(687):=	3319;
row_collector(688):=	3324;
row_collector(689):=	3325;
row_collector(690):=	3447;
row_collector(691):=	3448;
row_collector(692):=	3469;
row_collector(693):=	3477;
row_collector(694):=	3479;
row_collector(695):=	3484;
row_collector(696):=	3485;
row_collector(697):=	3487;
row_collector(698):=	3507;
row_collector(699):=	3517;
row_collector(700):=	3528;
row_collector(701):=	3533;
row_collector(702):=	3544;
row_collector(703):=	3548;
row_collector(704):=	3549;
row_collector(705):=	3556;
row_collector(706):=	3564;
row_collector(707):=	3565;
row_collector(708):=	3573;
row_collector(709):=	3621;
row_collector(710):=	3639;
row_collector(711):=	3640;
row_collector(712):=	3645;
row_collector(713):=	3656;
row_collector(714):=	3660;
row_collector(715):=	3661;
row_collector(716):=	3679;
row_collector(717):=	3692;
row_collector(718):=	3695;
row_collector(719):=	3708;
row_collector(720):=	3780;
row_collector(721):=	3784;
row_collector(722):=	3788;
row_collector(723):=	3789;
row_collector(724):=	3791;
row_collector(725):=	3800;
row_collector(726):=	3805;
row_collector(727):=	3812;
row_collector(728):=	3820;
row_collector(729):=	3821;
row_collector(730):=	3823;
row_collector(731):=	3836;
row_collector(732):=	3837;
row_collector(733):=	3895;
row_collector(734):=	3940;
row_collector(735):=	3941;
row_collector(736):=	3943;
row_collector(737):=	3960;
row_collector(738):=	3964;
row_collector(739):=	3981;
row_collector(740):=	4021;
row_collector(741):=	4028;
row_collector(742):=	4029;
row_collector(743):=	4040;
row_collector(744):=	4045;
row_collector(745):=	4056;
row_collector(746):=	4060;
row_collector(747):=	4061;
row_collector(748):=	4071;
row_collector(749):=	4076;
row_collector(750):=	4387;
row_collector(751):=	4388;
row_collector(752):=	4396;
row_collector(753):=	4403;
row_collector(754):=	4405;
row_collector(755):=	4407;
row_collector(756):=	4412;
row_collector(757):=	4413;
row_collector(758):=	4451;
row_collector(759):=	4452;
row_collector(760):=	4455;
row_collector(761):=	4460;
row_collector(762):=	4461;
row_collector(763):=	4467;
row_collector(764):=	4471;
row_collector(765):=	4472;
row_collector(766):=	4475;
row_collector(767):=	4493;
row_collector(768):=	4531;
row_collector(769):=	4533;
row_collector(770):=	4535;
row_collector(771):=	4539;
row_collector(772):=	4541;
row_collector(773):=	4543;
row_collector(774):=	4559;
row_collector(775):=	4573;
row_collector(776):=	4575;
row_collector(777):=	4588;
row_collector(778):=	4589;
row_collector(779):=	4645;
row_collector(780):=	4664;
row_collector(781):=	4676;
row_collector(782):=	4680;
row_collector(783):=	4684;
row_collector(784):=	4685;
row_collector(785):=	4696;
row_collector(786):=	4701;
row_collector(787):=	4703;
row_collector(788):=	4708;
row_collector(789):=	4716;
row_collector(790):=	4725;
row_collector(791):=	4727;
row_collector(792):=	4732;
row_collector(793):=	4797;
row_collector(794):=	4804;
row_collector(795):=	4805;
row_collector(796):=	4808;
row_collector(797):=	4812;
row_collector(798):=	4813;
row_collector(799):=	4815;
row_collector(800):=	4823;
row_collector(801):=	4824;
row_collector(802):=	4828;
row_collector(803):=	4829;
row_collector(804):=	4831;
row_collector(805):=	4836;
row_collector(806):=	4844;
row_collector(807):=	4845;
row_collector(808):=	4853;
row_collector(809):=	4855;
row_collector(810):=	4860;
row_collector(811):=	4861;
row_collector(812):=	4883;
row_collector(813):=	4885;
row_collector(814):=	4893;
row_collector(815):=	4917;
row_collector(816):=	4919;
row_collector(817):=	4920;
row_collector(818):=	4925;
row_collector(819):=	4957;
row_collector(820):=	4963;
row_collector(821):=	4964;
row_collector(822):=	4965;
row_collector(823):=	4967;
row_collector(824):=	4972;
row_collector(825):=	4973;
row_collector(826):=	4984;
row_collector(827):=	4989;
row_collector(828):=	5005;
row_collector(829):=	5020;
row_collector(830):=	5045;
row_collector(831):=	5047;
row_collector(832):=	5048;
row_collector(833):=	5051;
row_collector(834):=	5053;
row_collector(835):=	5060;
row_collector(836):=	5068;
row_collector(837):=	5079;
row_collector(838):=	5080;
row_collector(839):=	5084;
row_collector(840):=	5085;
row_collector(841):=	5100;
row_collector(842):=	5516;
row_collector(843):=	5517;
row_collector(844):=	5523;
row_collector(845):=	5525;
row_collector(846):=	5527;
row_collector(847):=	5528;
row_collector(848):=	5531;
row_collector(849):=	5532;
row_collector(850):=	5533;
row_collector(851):=	5535;
row_collector(852):=	5555;
row_collector(853):=	5557;
row_collector(854):=	5559;
row_collector(855):=	5561;
row_collector(856):=	5564;
row_collector(857):=	5565;
row_collector(858):=	5572;
row_collector(859):=	5573;
row_collector(860):=	5576;
row_collector(861):=	5580;
row_collector(862):=	5581;
row_collector(863):=	5592;
row_collector(864):=	5596;
row_collector(865):=	5597;
row_collector(866):=	5599;
row_collector(867):=	5603;
row_collector(868):=	5604;
row_collector(869):=	5612;
row_collector(870):=	5613;
row_collector(871):=	5623;
row_collector(872):=	5627;
row_collector(873):=	5628;
row_collector(874):=	5629;
row_collector(875):=	5669;
row_collector(876):=	5692;
row_collector(877):=	5693;
row_collector(878):=	5700;
row_collector(879):=	5704;
row_collector(880):=	5708;
row_collector(881):=	5709;
row_collector(882):=	5719;
row_collector(883):=	5720;
row_collector(884):=	5725;
row_collector(885):=	5733;
row_collector(886):=	5740;
row_collector(887):=	5741;
row_collector(888):=	5743;
row_collector(889):=	5749;
row_collector(890):=	5751;
row_collector(891):=	5756;
row_collector(892):=	5828;
row_collector(893):=	5829;
row_collector(894):=	5832;
row_collector(895):=	5836;
row_collector(896):=	5837;
row_collector(897):=	5839;
row_collector(898):=	5847;
row_collector(899):=	5848;
row_collector(900):=	5852;
row_collector(901):=	5853;
row_collector(902):=	5855;
row_collector(903):=	5860;
row_collector(904):=	5861;
row_collector(905):=	5868;
row_collector(906):=	5869;
row_collector(907):=	5879;
row_collector(908):=	5884;
row_collector(909):=	5885;
row_collector(910):=	5916;
row_collector(911):=	5917;
row_collector(912):=	5924;
row_collector(913):=	5943;
row_collector(914):=	5949;
row_collector(915):=	5981;
row_collector(916):=	5988;
row_collector(917):=	5989;
row_collector(918):=	5996;
row_collector(919):=	5997;
row_collector(920):=	6005;
row_collector(921):=	6007;
row_collector(922):=	6008;
row_collector(923):=	6012;
row_collector(924):=	6013;
row_collector(925):=	6015;
row_collector(926):=	6045;
row_collector(927):=	6067;
row_collector(928):=	6069;
row_collector(929):=	6077;
row_collector(930):=	6084;
row_collector(931):=	6092;
row_collector(932):=	6093;
row_collector(933):=	6095;
row_collector(934):=	6104;
row_collector(935):=	6108;
row_collector(936):=	6109;
row_collector(937):=	6116;
row_collector(938):=	6124;
row_collector(939):=	6125;
row_collector(940):=	6436;
row_collector(941):=	6437;
row_collector(942):=	6439;
row_collector(943):=	6444;
row_collector(944):=	6445;
row_collector(945):=	6451;
row_collector(946):=	6453;
row_collector(947):=	6455;
row_collector(948):=	6456;
row_collector(949):=	6460;
row_collector(950):=	6461;
row_collector(951):=	6463;
row_collector(952):=	6493;
row_collector(953):=	6499;
row_collector(954):=	6500;
row_collector(955):=	6501;
row_collector(956):=	6509;
row_collector(957):=	6519;
row_collector(958):=	6520;
row_collector(959):=	6524;
row_collector(960):=	6525;
row_collector(961):=	6541;
row_collector(962):=	6549;
row_collector(963):=	6551;
row_collector(964):=	6556;
row_collector(965):=	6557;
row_collector(966):=	6559;
row_collector(967):=	6572;
row_collector(968):=	6579;
row_collector(969):=	6581;
row_collector(970):=	6588;
row_collector(971):=	6589;
row_collector(972):=	6591;
row_collector(973):=	6596;
row_collector(974):=	6600;
row_collector(975):=	6604;
row_collector(976):=	6605;
row_collector(977):=	6616;
row_collector(978):=	6620;
row_collector(979):=	6621;
row_collector(980):=	6628;
row_collector(981):=	6636;
row_collector(982):=	6637;
row_collector(983):=	6653;
row_collector(984):=	6892;
row_collector(985):=	6940;
row_collector(986):=	6941;
row_collector(987):=	6943;
row_collector(988):=	6956;
row_collector(989):=	7005;
row_collector(990):=	7032;
row_collector(991):=	7036;
row_collector(992):=	7037;
row_collector(993):=	7053;
row_collector(994):=	7061;
row_collector(995):=	7084;
row_collector(996):=	7093;
row_collector(997):=	7101;
row_collector(998):=	7112;
row_collector(999):=	7117;
row_collector(1000):=	7128;



    FOR i IN 1..1000 LOOP
        EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT(''COVERYPE_K'',''ORIGINAL_ATTR'', '||row_collector(i)||', '||j+i||')';
    END LOOP;


END INSERT_VITAUL;



/
--------------------------------------------------------
--  DDL for Procedure M_SCH_EXP
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."M_SCH_EXP" ( RELATION IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT, CANT_ATTR IN INT,PRIV_KEY IN VARCHAR2) IS
    id_cursor sys_refcursor;
    id_row NUMBER;
    attr_01 INT;
    attr_02 INT;
    attr_03 INT;
    attr_04 INT;
    attr_05 INT;
    attr_06 INT;
    attr_07 INT;
    attr_08 INT;
    attr_09 INT;
    attr_10 INT;
    value_row INT;
    concatenated_value VARCHAR2(80);
    row_collector NUMBER_ARRAY;
    name_collector VARCHAR_ARRAY;
    l_idx int;

BEGIN
    row_collector := NUMBER_ARRAY();
    row_collector.EXTEND(10);

    name_collector := VARCHAR_ARRAY();
    name_collector.EXTEND(10);

    name_collector(1):= 'ELEVATION';
    name_collector(2):= 'ASPECT';
    name_collector(3):= 'SLOPE';
    name_collector(4):= 'HOR_DIST_TO_HYDROLOGY';
    name_collector(5):= 'VERT_DIST_TO_HYDROLOGY';
    name_collector(6):= 'HOR_DIST_TO_ROADWAYS';
    name_collector(7):= 'HILLSHADE_9AM';
    name_collector(8):= 'HILLSHADE_NOON';
    name_collector(9):= 'HILLSHADE_3PM';
    name_collector(10):= 'HOR_DIST_TO_FIRE_POINTS';



    EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '''', 0)';



    OPEN id_cursor FOR 
    'SELECT ID AS IDENT,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION              )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS ELEV_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT                 )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS ASP_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE                  )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS SLOP_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY  )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTH_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS VDTH_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS   )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTR_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM          )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDIX_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON         )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDN_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM          )),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDIII_VALUE,
             CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTFP_VALUE

     FROM '||RELATION ||' 

     WHERE  LENGTH(num_to_bin(ELEVATION              )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(ASPECT                 )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND
            LENGTH(num_to_bin(SLOPE                  )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY  )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND
            LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS   )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_9AM          )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(HILLSHADE_NOON         )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_3PM          )) >= '||MSB_COUNT ||'+'||LSB_COUNT||' AND 
            LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT ||'+'||LSB_COUNT;

    LOOP
        FETCH id_cursor INTO id_row, attr_01, attr_02, attr_03, attr_04, attr_05, attr_06, attr_07, attr_08, attr_09, attr_10;
        EXIT WHEN id_cursor%NOTFOUND;

        row_collector(1):= attr_01;
        row_collector(2):= attr_02;
        row_collector(3):= attr_03;
        row_collector(4):= attr_04;
        row_collector(5):= attr_05;
        row_collector(6):= attr_06;
        row_collector(7):= attr_07;
        row_collector(8):= attr_08;
        row_collector(9):= attr_09;
        row_collector(10):= attr_10;

        SELECT CAST (MULTISET(SELECT * FROM TABLE (row_collector) ORDER BY 1) AS NUMBER_ARRAY) INTO row_collector FROM dual;

       --CODE SNIPPET TO PRINT THE ARRAY CORESPONDING TO THE RECORD
        --l_idx:= row_collector.first;
        --dbms_output.put_line('New record');

        --LOOP
        --    dbms_output.put_line(row_collector(l_idx));
        --    l_idx:= row_collector.NEXT(l_idx);
        --    EXIT WHEN l_idx IS NULL;
        --END LOOP;


        FOR i IN 1..CANT_ATTR LOOP

            dbms_output.put_line(row_collector(i));
            dbms_output.put_line( TO_CHAR(num_to_bin(row_collector(i))));


            concatenated_value := concatenated_value || TO_CHAR(num_to_bin(row_collector(i)));

        END LOOP;

        concatenated_value:='';

    END LOOP;

    CLOSE id_cursor; 


END M_SCH_EXP;

/
--------------------------------------------------------
--  DDL for Procedure MEANCLOSEST
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."MEANCLOSEST" (RELATION IN VARCHAR2, MSB_RANGE IN INT, PRIV_KEY IN VARCHAR2, INC_SEED IN INT) IS
    id_cursor sys_refcursor;
    id_row NUMBER;
    vpk_1 INT;
    tpl_seed INT;
    group_size INT;
    attr_01 INT;
    attr_02 INT;
    attr_03 INT;
    attr_04 INT;
    attr_05 INT;
    attr_06 INT;
    attr_07 INT;
    attr_08 INT;
    attr_09 INT;
    attr_10 INT;
    row_collector NUMBER_ARRAY;

    value_toembedd INT;
    closest_value INT;
    sel_val_pos   INT;

    avg_value FLOAT;

    i int;

BEGIN
    i := 0;
    avg_value := 0;
    value_toembedd := 0;

    row_collector := NUMBER_ARRAY();
    row_collector.EXTEND(10);

    EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''VPK_II'', '''', 0)';

    OPEN id_cursor FOR 
    'SELECT ID AS IDENT, VPK_I, TUPL_SEED, GROUP_SIZE,
            GENERATE_FROM_MSB(ASPECT,'||MSB_RANGE||','''||PRIV_KEY||''')                  AS ATTR_01,
            GENERATE_FROM_MSB(ELEVATION,'||MSB_RANGE||','''||PRIV_KEY||''')               AS ATTR_02,
            GENERATE_FROM_MSB(HILLSHADE_3PM,'||MSB_RANGE||','''||PRIV_KEY||''')           AS ATTR_03,
            GENERATE_FROM_MSB(HILLSHADE_9AM,'||MSB_RANGE||','''||PRIV_KEY||''')           AS ATTR_04,
            GENERATE_FROM_MSB(HILLSHADE_NOON,'||MSB_RANGE||','''||PRIV_KEY||''')          AS ATTR_05,
            GENERATE_FROM_MSB(HOR_DIST_TO_FIRE_POINTS,'||MSB_RANGE||','''||PRIV_KEY||''') AS ATTR_06,
            GENERATE_FROM_MSB(HOR_DIST_TO_HYDROLOGY,'||MSB_RANGE||','''||PRIV_KEY||''')   AS ATTR_07,
            GENERATE_FROM_MSB(HOR_DIST_TO_ROADWAYS,'||MSB_RANGE||','''||PRIV_KEY||''')    AS ATTR_08,
            GENERATE_FROM_MSB(SLOPE,'||MSB_RANGE||','''||PRIV_KEY||''')                   AS ATTR_09,
            GENERATE_FROM_MSB(VERT_DIST_TO_HYDROLOGY,'||MSB_RANGE||','''||PRIV_KEY||''')  AS ATTR_10
    FROM '||RELATION;

    LOOP
        FETCH id_cursor INTO id_row, vpk_1,tpl_seed, group_size, attr_01, attr_02, attr_03, attr_04, attr_05, attr_06, attr_07, attr_08, attr_09, attr_10;
        EXIT WHEN id_cursor%NOTFOUND;

        row_collector(1) := attr_01;
        row_collector(2) := attr_02;
        row_collector(3) := attr_03;
        row_collector(4) := attr_04;
        row_collector(5) := attr_05;
        row_collector(6) := attr_06;
        row_collector(7) := attr_07;
        row_collector(8) := attr_08;
        row_collector(9) := attr_09;
        row_collector(10):= attr_10;

        IF tpl_seed is null THEN
            tpl_seed := INC_SEED;
        ELSE
            tpl_seed := tpl_seed + INC_SEED;
        END IF;

        --FOR AVOID ERROR BY PASSING VPK OUT OF THE PLSQL INTIGER DATA TYPE RANGE
        WHILE tpl_seed >= 2147483647 LOOP
            tpl_seed := tpl_seed - 2147483647;
        END LOOP;

        --FOR S-SCHEME 3MSB //7	6837  //5	7631  //6	7759  //4	7773
        --utm as wm
        --dbms_output.put_line(tpl_seed);

       -- IF vpk_1 = 0 THEN 
       --       SELECT ORA_HASH(1,554,tpl_seed) INTO value_toembedd FROM dual;
       -- ELSE IF vpk_1 = 6 THEN 
       --       SELECT ORA_HASH(7,963,tpl_seed)  + 554 INTO value_toembedd FROM dual;
       -- ELSE IF vpk_1 = 4 THEN 
       --       SELECT ORA_HASH(5,1564,tpl_seed) + 554 + 963 INTO value_toembedd FROM dual;
       -- ELSE IF vpk_1 = 5 THEN 
       --       SELECT ORA_HASH(6,1690,tpl_seed) + 554 + 963 + 1564 INTO value_toembedd FROM dual;
       -- ELSE IF vpk_1 = 7 THEN     
       --       SELECT ORA_HASH(8,1786,tpl_seed) + 554 + 963 + 1564 + 1690 INTO value_toembedd FROM dual;


        IF vpk_1 = 7 THEN 
              SELECT ORA_HASH(7,80,tpl_seed) INTO value_toembedd FROM dual;
        IF vpk_1 = 6 THEN 
              SELECT ORA_HASH(6,1205,tpl_seed) + 80 INTO value_toembedd FROM dual;
        ELSE IF vpk_1 = 4 THEN 
              SELECT ORA_HASH(4,1379,tpl_seed) + 80 + 1205 INTO value_toembedd FROM dual;
         ELSE IF vpk_1 = 5 THEN 
              SELECT ORA_HASH(5,3893,tpl_seed) + 80 + 1205 + 1379 INTO value_toembedd FROM dual;

        --chinese character as wm
        --IF vpk_1 = 7 THEN 
        --      SELECT ORA_HASH(vpk_1,96,tpl_seed) INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 5 THEN 
        --      SELECT ORA_HASH(vpk_1,107,tpl_seed) + 96 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 6 THEN 
        --      SELECT ORA_HASH(vpk_1,109,tpl_seed) + 96 + 107 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 4 THEN 
        --      SELECT ORA_HASH(vpk_1,109,tpl_seed) + 96 + 107 + 109 INTO value_toembedd FROM dual;

        --e character as wm
        --IF vpk_1 = 7 THEN 
        --      SELECT ORA_HASH(vpk_1,23,tpl_seed) INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 5 THEN 
        --      SELECT ORA_HASH(vpk_1,25,tpl_seed) + 23 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 6 THEN 
        --      SELECT ORA_HASH(vpk_1,26,tpl_seed) + 25 + 23 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 4 THEN 
        --      SELECT ORA_HASH(vpk_1,26,tpl_seed) + 26 + 25 + 23 INTO value_toembedd FROM dual;

        --END IF;
        --END IF;
        --END IF;
        --END IF;

        --FOR M-SCHEME 3MSB 2 attr...
        --utm as wm
        --IF vpk_1 = 11145213339966881915 THEN 
        --      SELECT ORA_HASH(vpk_1,2,tpl_seed) INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 7655090273485832315 THEN 
        --      SELECT ORA_HASH(vpk_1,5,tpl_seed) + 2 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 4060352837445206139 THEN 
        --      SELECT ORA_HASH(vpk_1,8,tpl_seed) + 2 + 5 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 3827545137227782155 THEN 
        --      SELECT ORA_HASH(vpk_1,175,tpl_seed) + 2 + 5 + 8 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 2030176419207469067 THEN 
        --      SELECT ORA_HASH(vpk_1,701,tpl_seed) + 2 + 5 + 8 + 175 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 is null THEN 
        --      SELECT ORA_HASH(vpk_1,2666,tpl_seed) + 2 + 5 + 8 + 175 + 701 INTO value_toembedd FROM dual;
        -- ELSE IF vpk_1 = 1015088209657939300 THEN 
        --      SELECT ORA_HASH(vpk_1,3003,tpl_seed) + 2 + 5 + 8 + 175 + 701 + 2666 INTO value_toembedd FROM dual;

        --chinese character as wm
        --IF vpk_1 = 11145213339966881915 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 7655090273485832315 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 4060352837445206139 THEN 
        --      SELECT ORA_HASH(vpk_1,1,tpl_seed) + 0 + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 3827545137227782155 THEN 
        --      SELECT ORA_HASH(vpk_1,11,tpl_seed) + 0 + 0 + 1 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 2030176419207469067 THEN 
        --      SELECT ORA_HASH(vpk_1,45,tpl_seed) + 0 + 0 + 1 + 11 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 is null THEN 
        --      SELECT ORA_HASH(0,171,tpl_seed) + 0 + 0 + 1 + 11 + 45 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 1015088209657939300 THEN 
        --      SELECT ORA_HASH(vpk_1,192,tpl_seed) + 0 + 0 + 1 + 11 + 45 + 171 INTO value_toembedd FROM dual;

        --e character as wm
        --IF vpk_1 = 11145213339966881915 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 7655090273485832315 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 4060352837445206139 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) + 0 + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 3827545137227782155 THEN 
        --      SELECT ORA_HASH(vpk_1,3,tpl_seed) + 0 + 0 + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 2030176419207469067 THEN 
        --      SELECT ORA_HASH(vpk_1,11,tpl_seed) + 0 + 0 + 0 + 3 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 is null THEN 
        --      SELECT ORA_HASH(0,41,tpl_seed) + 0 + 0 + 0 + 3 + 11 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 1015088209657939300 THEN 
        --      SELECT ORA_HASH(vpk_1,46,tpl_seed) + 0 + 0 + 0 + 3 + 11 + 41 INTO value_toembedd FROM dual;

        -- IGNORANDO A LAS LLAVES QUE QUEDARON NULL
        --utm as wm
    --    IF vpk_1 = 11145213339966881915 THEN 
    --          SELECT ORA_HASH(vpk_1,4,tpl_seed) INTO value_toembedd FROM dual;
    --    ELSE IF vpk_1 = 7655090273485832315 THEN 
    --          SELECT ORA_HASH(vpk_1,15,tpl_seed) + 4 INTO value_toembedd FROM dual;
    --    ELSE IF vpk_1 = 4060352837445206139 THEN 
    --          SELECT ORA_HASH(vpk_1,41,tpl_seed) + 4 + 15 INTO value_toembedd FROM dual;
    --    ELSE IF vpk_1 = 3827545137227782155 THEN 
    --         SELECT ORA_HASH(vpk_1,314,tpl_seed) + 4 + 15 + 41 INTO value_toembedd FROM dual;
    --    ELSE IF vpk_1 = 2030176419207469067 THEN 
    --          SELECT ORA_HASH(vpk_1,1273,tpl_seed) + 4 + 15 + 41 + 314 INTO value_toembedd FROM dual;
    --    ELSE IF vpk_1 = 1015088209657939300 THEN 
    --          SELECT ORA_HASH(vpk_1,4913,tpl_seed) + 4 + 15 + 41 + 314 + 1273 INTO value_toembedd FROM dual;

        --chinese character as wm
        --IF vpk_1 = 11145213339966881915 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 7655090273485832315 THEN 
        --      SELECT ORA_HASH(vpk_1,1,tpl_seed) + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 4060352837445206139 THEN 
        --      SELECT ORA_HASH(vpk_1,1,tpl_seed) + 0 + 1 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 3827545137227782155 THEN 
        --      SELECT ORA_HASH(vpk_1,19,tpl_seed) + 0 + 1 + 1 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 2030176419207469067 THEN 
        --      SELECT ORA_HASH(vpk_1,76,tpl_seed) + 0 + 1 + 1 + 19 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 1015088209657939300 THEN 
        --      SELECT ORA_HASH(vpk_1,324,tpl_seed) + 0 + 1 + 1 + 19 + 76 INTO value_toembedd FROM dual;

        --e character as wm
        --IF vpk_1 = 11145213339966881915 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 7655090273485832315 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 4060352837445206139 THEN 
        --      SELECT ORA_HASH(vpk_1,0,tpl_seed) + 0 + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 3827545137227782155 THEN 
        --      SELECT ORA_HASH(vpk_1,5,tpl_seed) + 0 + 0 + 0 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 2030176419207469067 THEN 
        --      SELECT ORA_HASH(vpk_1,18,tpl_seed) + 0 + 0 + 0 + 5 INTO value_toembedd FROM dual;
        --ELSE IF vpk_1 = 1015088209657939300 THEN 
        --      SELECT ORA_HASH(vpk_1,77,tpl_seed) + 0 + 0 + 0 + 5 + 18  INTO value_toembedd FROM dual;


        END IF;
        END IF;
        END IF;
        END IF;
       -- END IF;

        i := i + 1;

        --dbms_output.put_line(i);

        --IF id_row = 3327 THEN
        IF value_toembedd is null THEN
            EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''VPK_II'', null, '||id_row||')';
        ELSE
            EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''VPK_II'', '||value_toembedd||', '||id_row||')';
        END IF;

       avg_value := 0; 


    END LOOP;

    CLOSE id_cursor;

       EXCEPTION 
        WHEN OTHERS 
        THEN dbms_output.put_line(tpl_seed);

END MEANCLOSEST;

/
--------------------------------------------------------
--  DDL for Procedure METRIC_KULLBACK_LEIBLER_DIVERGENCE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."METRIC_KULLBACK_LEIBLER_DIVERGENCE" (RELATION IN VARCHAR2, ATTR_ORIG IN VARCHAR2, ATTR_DIST IN VARCHAR2) AS 
    id_cursor sys_refcursor;
    attr_name  VARCHAR2(200);
    prob_val FLOAT;
    counter INT;
BEGIN

     EXECUTE IMMEDIATE 'INSERT INTO TABLE1 SELECT ' ||ATTR_ORIG|| ' AS ATTR_P, COUNT(*)/30000 AS PROB_P, 0 FROM COVERTYPE_A GROUP BY ' ||ATTR_ORIG;

     OPEN id_cursor FOR 'SELECT ' ||ATTR_DIST|| ' AS ATTR_Q, COUNT(*)/30000 AS PROB_Q FROM COVERTYPE_A GROUP BY ' ||ATTR_DIST;


  LOOP
    FETCH id_cursor INTO attr_name, prob_val;
    EXIT WHEN id_cursor%NOTFOUND;

    SELECT COUNT(*) INTO counter FROM TABLE1 WHERE ATTR_VAL = attr_name;

    IF counter > 0 THEN 
        EXECUTE IMMEDIATE 'UPDATE TABLE1 SET  PROB_Q=:1 WHERE ATTR_VAL =:2' USING prob_val, attr_name;
    ELSE
        EXECUTE IMMEDIATE 'INSERT INTO TABLE1 (ATTR_VAL, PROB_P, PROB_Q) VALUES (:1, 0, :2)' USING attr_name, prob_val;
    END IF;


  END LOOP; 


  CLOSE id_cursor;
END METRIC_KULLBACK_LEIBLER_DIVERGENCE;

/
--------------------------------------------------------
--  DDL for Procedure POS_RANDOMIZER
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."POS_RANDOMIZER" (VPK IN VARCHAR2, IMAGE_HEIGHT IN INT, IMAGE_WIDTH IN INT, H OUT INT, W OUT INT) IS 
BEGIN
  SELECT ORA_HASH(VPK,IMAGE_HEIGHT,1) INTO H FROM dual;
  SELECT ORA_HASH(VPK,IMAGE_WIDTH,2) INTO W FROM dual;
END POS_RANDOMIZER;

/
--------------------------------------------------------
--  DDL for Procedure RESP_ATTR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RESP_ATTR" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2) IS
BEGIN
  EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET ATTR_RESP='||ATTR_NAME;
END RESP_ATTR;

/
--------------------------------------------------------
--  DDL for Procedure RESP_LLP
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RESP_LLP" (RELATION IN VARCHAR2) IS
BEGIN
  EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET LLP_RESP = LLP';
END RESP_LLP;

/
--------------------------------------------------------
--  DDL for Procedure RTW_ASSIGN_VPK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_ASSIGN_VPK" 
(
  RELATION IN VARCHAR2 
, SECRET_KEY IN VARCHAR2 
) AS 
BEGIN
  EXECUTE IMMEDIATE 'UPDATE ' || RELATION || ' SET VPK = CREATE_VPK(ID, ''' || SECRET_KEY || ''')';
END RTW_ASSIGN_VPK;

/
--------------------------------------------------------
--  DDL for Procedure RTW_ATTRS_CHECK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_ATTRS_CHECK" (P_B_EMB_LN IN VARCHAR2, P_B_EXT_LN IN VARCHAR2, P_B_EMB_LS IN VARCHAR2, P_B_EXT_LS IN VARCHAR2,
                                             P_B_EMB_SK IN VARCHAR2, P_B_EXT_SK IN VARCHAR2, P_B_EMB_SN IN VARCHAR2, P_B_EXT_SN IN VARCHAR2,
                                             P_B_EMB_SS IN VARCHAR2, P_B_EXT_SS IN VARCHAR2, P_B_EMB_MARC IN NUMBER, P_B_EXT_MARC IN NUMBER,
                                             P_B_EMB_SU IN VARCHAR2, P_B_EXT_SU IN VARCHAR2, P_TUPLE_ID IN NUMBER) IS
BEGIN
  EXECUTE IMMEDIATE 'UPDATE TEX_NEWS SET B_EMB_LN=:1,  B_EXT_LN=:2,  B_EMB_LS=:3,    B_EXT_LS=:4, 
                                         B_EMB_SK=:5,  B_EXT_SK=:6,  B_EMB_SN=:7,    B_EXT_SN=:8,
                                         B_EMB_SS=:9,  B_EXT_SS=:10, B_EMB_MARC=:11, B_EXT_MARC=:12, 
                                         B_EMB_SU=:13, B_EXT_SU=:14 
                    WHERE id =:15' USING P_B_EMB_LN, P_B_EXT_LN, P_B_EMB_LS,   P_B_EXT_LS,
                                         P_B_EMB_SK, P_B_EXT_SK, P_B_EMB_SN,   P_B_EXT_SN,
                                         P_B_EMB_SS, P_B_EXT_SS, P_B_EMB_MARC, P_B_EXT_MARC,
                                         P_B_EMB_SU, P_B_EXT_SU, P_TUPLE_ID;
END RTW_ATTRS_CHECK;

/
--------------------------------------------------------
--  DDL for Procedure RTW_EMB_BCHECK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_EMB_BCHECK" (P_B_EMB_LN IN VARCHAR2, P_B_EMB_LS IN VARCHAR2, 
                                            P_B_EMB_SK IN VARCHAR2, P_B_EMB_SN IN VARCHAR2,  
                                            P_B_EMB_SS IN VARCHAR2, P_B_EMB_MARC IN VARCHAR2,  
                                            P_B_EMB_SU IN VARCHAR2, P_TUPLE_ID IN NUMBER) IS
BEGIN
  EXECUTE IMMEDIATE 'UPDATE TEX_NEWS SET B_EMB_LN=:1,  B_EMB_LS=:2,   
                                         B_EMB_SK=:3,  B_EMB_SN=:4,   
                                         B_EMB_SS=:5,  B_EMB_MARC=:6,  
                                         B_EMB_SU=:7 
                    WHERE id =:8' USING P_B_EMB_LN, P_B_EMB_LS,    
                                        P_B_EMB_SK, P_B_EMB_SN,  
                                        P_B_EMB_SS, P_B_EMB_MARC,  
                                        P_B_EMB_SU, P_TUPLE_ID;
END RTW_EMB_BCHECK;

/
--------------------------------------------------------
--  DDL for Procedure RTW_EMB_WORD
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_EMB_WORD" (P_ID_TUPL IN NUMBER, P_ID_SENT IN NUMBER, P_EMB_WORD IN VARCHAR2, P_EMB_SYNSET IN NUMBER, P_EMB_MARC IN NUMBER) IS
BEGIN
  EXECUTE IMMEDIATE 'INSERT INTO REPL_WORDS (ID_TUPL, ID_SENT, EMB_WORD, EMB_SYNSET, EMB_MARC) VALUES (:1, :2, :3, :4, :5)' 
  USING P_ID_TUPL, P_ID_SENT, P_EMB_WORD, P_EMB_SYNSET, P_EMB_MARC;
END RTW_EMB_WORD;

/
--------------------------------------------------------
--  DDL for Procedure RTW_EXT_BCHECK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_EXT_BCHECK" (P_B_EXT_LN IN VARCHAR2, P_B_EXT_LS IN VARCHAR2, 
                                            P_B_EXT_SK IN VARCHAR2, P_B_EXT_SN IN VARCHAR2,  
                                            P_B_EXT_SS IN VARCHAR2, P_B_EXT_MARC IN VARCHAR2,  
                                            P_B_EXT_SU IN VARCHAR2, P_TUPLE_ID IN NUMBER) IS
BEGIN
  EXECUTE IMMEDIATE 'UPDATE TEX_NEWS SET B_EXT_LN=:1,  B_EXT_LS=:2,   
                                         B_EXT_SK=:3,  B_EXT_SN=:4,   
                                         B_EXT_SS=:5,  B_EXT_MARC=:6,  
                                         B_EXT_SU=:7 
                    WHERE id =:8' USING P_B_EXT_LN, P_B_EXT_LS,    
                                        P_B_EXT_SK, P_B_EXT_SN,  
                                        P_B_EXT_SS, P_B_EXT_MARC,  
                                        P_B_EXT_SU, P_TUPLE_ID;
END RTW_EXT_BCHECK;

/
--------------------------------------------------------
--  DDL for Procedure RTW_EXT_WORD
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_EXT_WORD" (P_ID_TUPL IN NUMBER, P_ID_SENT IN NUMBER, P_EXT_WORD IN VARCHAR2, P_EXT_SYNSET IN NUMBER, P_EXT_MARC IN NUMBER) IS
BEGIN
  EXECUTE IMMEDIATE 'UPDATE REPL_WORDS SET EXT_WORD=:1, EXT_SYNSET=:2, EXT_MARC=:3 WHERE ID_TUPL =:4 AND ID_SENT =:5' 
  USING P_EXT_WORD, P_EXT_SYNSET, P_EXT_MARC, P_ID_TUPL, P_ID_SENT;
END RTW_EXT_WORD;

/
--------------------------------------------------------
--  DDL for Procedure RTW_GENERATE_CONSFACTOR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_GENERATE_CONSFACTOR" (RELATION IN VARCHAR2, TUPLE_FRACT IN NUMBER) IS 
BEGIN
  EXECUTE IMMEDIATE 'UPDATE ' ||RELATION|| ' SET TUPL_FACTOR = MOD(VPK,'||TUPLE_FRACT||')';
END RTW_GENERATE_CONSFACTOR;

/
--------------------------------------------------------
--  DDL for Procedure RTW_GENERATE_VPK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_GENERATE_VPK" (RELATION IN VARCHAR2, TUPLE_ID IN NUMBER, VPK_SOURCE IN INT, SECRET_KEY IN VARCHAR2) IS 
vpk INT;
BEGIN
  SELECT ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => VPK_SOURCE || SECRET_KEY)) AS VPK INTO vpk FROM dual;

  EXECUTE IMMEDIATE 'UPDATE ' ||RELATION|| ' SET VPK =:1 WHERE ID =:2' USING vpk, TUPLE_ID;

END RTW_GENERATE_VPK;

/
--------------------------------------------------------
--  DDL for Procedure RTW_UPDATE_ATTR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."RTW_UPDATE_ATTR" ( RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, ATTR_VALUE IN CLOB, TUPLE_ID IN NUMBER ) IS
BEGIN
  IF TUPLE_ID > 0 THEN
    EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1 WHERE id =:2' USING ATTR_VALUE, TUPLE_ID;
  ELSE
    EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1' USING ATTR_VALUE;
  END IF;
END RTW_UPDATE_ATTR;

/
--------------------------------------------------------
--  DDL for Procedure SAMPLE_W
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."SAMPLE_W" IS 
    id_list sys_refcursor;
    current_id NUMBER;--id_list%ROWTYPE;
    temp NUMBER;
BEGIN
    OPEN id_list FOR 'SELECT id FROM covertype_vii';
    LOOP
        FETCH id_list INTO current_id;
        EXIT WHEN id_list%NOTFOUND;
        --SELECT SLOPE + 1 INTO temp FROM covertype_vii WHERE id = current_id ;
        EXECUTE IMMEDIATE 'UPDATE covertype_vii SET SLOPE=:1 WHERE id =:2'USING temp, current_id;
    END LOOP;
    COMMIT;
    CLOSE id_list;
END SAMPLE_W;

/
--------------------------------------------------------
--  DDL for Procedure SCHEME_2018
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."SCHEME_2018" (RELATION IN VARCHAR2, LSB_RANGE IN INT, MAX_ITEMS IN INT, PRIV_KEY IN VARCHAR2) IS
    id_cursor sys_refcursor;
    id_row NUMBER;
    attr_01 INT;
    attr_02 INT;
    attr_03 INT;
    attr_04 INT;
    attr_05 INT;
    attr_06 INT;
    attr_07 INT;
    attr_08 INT;
    attr_09 INT;
    attr_10 INT;
    row_collector NUMBER_ARRAY;
    attr_counter NUMBER_ARRAY;
    final_counter NUMBER_ARRAY;

    row_counter NUMBER_ARRAY;

    max_value INT;
    max_value_pos INT;

    avg_value FLOAT;

    temp_consid VARCHAR2(200);
    binary_val VARCHAR2(200);
    rexp_value VARCHAR2(200);
    din_index INT;

    up_down INT;

    rii INT;
    lee INT;
    j INT;


    tuples INT;

    attr_erased INT;
    skip_vpk INT;

    val_01 INT;
    val_02 INT;
    val_03 INT;
    val_04 INT;
    val_05 INT;
    val_06 INT;
    val_07 INT;
    val_08 INT;
    val_09 INT;
    val_10 INT;

BEGIN

    val_01 := 0;
    val_02 := 0;
    val_03 := 0;
    val_04 := 0;
    val_05 := 0;
    val_06 := 0;
    val_07 := 0;
    val_08 := 0;
    val_09 := 0;
    val_10 := 0;

    attr_erased := 11;
    skip_vpk :=0;


up_down := 0;
tuples := 0;
    binary_val := '';
    rexp_value := '';
    rii := 0;
    lee := 0;
    j := 0;
    avg_value := 0;


    row_collector := NUMBER_ARRAY();
    row_collector.EXTEND(10);

    attr_counter := NUMBER_ARRAY();
    attr_counter.EXTEND(10);

    final_counter := NUMBER_ARRAY();
    final_counter.EXTEND(10);


    row_counter := NUMBER_ARRAY();
    row_counter.EXTEND(10);

    FOR i IN 1..10 LOOP
            row_counter(i):=0;
    END LOOP;



    FOR k IN 1..10 LOOP
        final_counter(k) := 0;
    END LOOP;


    --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '''', 0)';
    EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', '''', 0)';

    OPEN id_cursor FOR 
    'SELECT ID AS IDENT,
            GENERATE_VALUE(ASPECT,'||LSB_RANGE||','''||PRIV_KEY||''')                  AS ATTR_01,
            GENERATE_VALUE(ELEVATION,'||LSB_RANGE||','''||PRIV_KEY||''')               AS ATTR_02,
            GENERATE_VALUE(HILLSHADE_3PM,'||LSB_RANGE||','''||PRIV_KEY||''')           AS ATTR_03,
            GENERATE_VALUE(HILLSHADE_9AM,'||LSB_RANGE||','''||PRIV_KEY||''')           AS ATTR_04,
            GENERATE_VALUE(HILLSHADE_NOON,'||LSB_RANGE||','''||PRIV_KEY||''')          AS ATTR_05,
            GENERATE_VALUE(HOR_DIST_TO_FIRE_POINTS,'||LSB_RANGE||','''||PRIV_KEY||''') AS ATTR_06,
            GENERATE_VALUE(HOR_DIST_TO_HYDROLOGY,'||LSB_RANGE||','''||PRIV_KEY||''')   AS ATTR_07,
            GENERATE_VALUE(HOR_DIST_TO_ROADWAYS,'||LSB_RANGE||','''||PRIV_KEY||''')    AS ATTR_08,
            GENERATE_VALUE(SLOPE,'||LSB_RANGE||','''||PRIV_KEY||''')                   AS ATTR_09,
            GENERATE_VALUE(VERT_DIST_TO_HYDROLOGY,'||LSB_RANGE||','''||PRIV_KEY||''')  AS ATTR_10
    FROM '||RELATION;

    LOOP
        FETCH id_cursor INTO id_row, attr_01, attr_02, attr_03, attr_04, attr_05, attr_06, attr_07, attr_08, attr_09, attr_10;
        EXIT WHEN id_cursor%NOTFOUND;

        row_collector(1) := attr_01;
        row_collector(2) := attr_02;
        row_collector(3) := attr_03;
        row_collector(4) := attr_04;
        row_collector(5) := attr_05;
        row_collector(6) := attr_06;
        row_collector(7) := attr_07;
        row_collector(8) := attr_08;
        row_collector(9) := attr_09;
        row_collector(10):= attr_10;

        FOR x IN 1..10 LOOP
            attr_counter(x) := 0;
        END LOOP;

        binary_val := '';
        rexp_value := '';
        j := 1;

        max_value_pos := 1;
        max_value := row_collector(max_value_pos);

        FOR z IN 1..row_collector.COUNT LOOP
            avg_value := avg_value + row_collector(z);
        END LOOP;
        avg_value := avg_value/row_collector.COUNT;

        FOR i IN 2..row_collector.COUNT LOOP
            IF max_value < row_collector(i) THEN
                max_value_pos := i;
                max_value := row_collector(max_value_pos);
            END IF;
        END LOOP;

        din_index := max_value_pos;


        attr_counter(max_value_pos):= 1;


        --IF id_row IN (2106, 473, 1332, 2175, 5454, 3899) THEN

        --dbms_output.put_line('ID: '||id_row);



        up_down := MOD(REGEXP_COUNT(TO_CHAR(num_to_bin(row_collector(din_index))), '0'),2);

        IF MOD(max_value,2) = 0 THEN
            --rii := rii + 1;
            --right movement

            IF up_down = 0 THEN
                WHILE j <= MAX_ITEMS LOOP
                    IF row_collector(din_index) > avg_value THEN
                        binary_val := binary_val || TO_CHAR(num_to_bin(row_collector(din_index)));
                        j := j+1;

                        --dbms_output.put_line(din_index);

                        attr_counter(din_index):= 1;

                        row_counter(din_index):= row_counter(din_index)+1;

                    END IF;
                    din_index := din_index + 1;
                    IF din_index > row_collector.COUNT THEN
                        din_index := din_index - row_collector.COUNT;
                    END IF;
                END LOOP;
            ELSE
                WHILE j <= MAX_ITEMS LOOP
                    IF row_collector(din_index) < avg_value THEN
                        binary_val := binary_val || TO_CHAR(num_to_bin(row_collector(din_index)));
                        j := j+1;

                                                --dbms_output.put_line(din_index);


                        attr_counter(din_index):= 1;
                        row_counter(din_index):= row_counter(din_index)+1;
                    END IF;
                    din_index := din_index + 1;
                    IF din_index > row_collector.COUNT THEN
                        din_index := din_index - row_collector.COUNT;
                    END IF;
                END LOOP;
            END IF;
        ELSE
            --lee := lee + 1;
            --left movement
            IF up_down = 0 THEN
                WHILE j <= MAX_ITEMS LOOP
                    IF row_collector(din_index) > avg_value THEN
                        binary_val := binary_val || TO_CHAR(num_to_bin(row_collector(din_index)));
                        j := j+1;

                                               -- dbms_output.put_line(din_index);

                        attr_counter(din_index):= 1;
                        row_counter(din_index):= row_counter(din_index)+1;
                    END IF;
                    din_index := din_index - 1;

                    IF din_index <= 0 THEN
                        din_index := din_index + row_collector.COUNT;
                    END IF;

                END LOOP;
            ELSE
                WHILE j <= MAX_ITEMS LOOP
                    IF row_collector(din_index) < avg_value THEN
                        binary_val := binary_val || TO_CHAR(num_to_bin(row_collector(din_index)));
                        j := j+1;

                                              --  dbms_output.put_line(din_index);


                        attr_counter(din_index):= 1;
                        row_counter(din_index):= row_counter(din_index)+1;
                    END IF;
                    din_index := din_index - 1;
                    IF din_index <= 0 THEN
                        din_index := din_index + row_collector.COUNT;
                    END IF;
                END LOOP;
            END IF;
        END IF;

          --dbms_output.put_line(BINARY_CHAR_TO_INTEGER(binary_val) - max_value);

        --9542
        binary_val := BINARY_CHAR_TO_INTEGER(TO_CHAR(num_to_bin(BINARY_CHAR_TO_INTEGER(binary_val) - max_value)));

        rexp_value := BINARY_CHAR_TO_INTEGER(TO_CHAR(num_to_bin(row_collector(MOD(max_value,row_collector.COUNT)+1))));

        attr_counter(MOD(max_value,row_collector.COUNT)+1):= 1;

        ---BINARY_CHAR_TO_INTEGER(binary_val);

        --52.96



       -- EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '||INC_VARIABILITY(binary_val,3)||', '||id_row||')';
        --INC_VARIABILITY no es muy buena poruqe los resutlados son los mismos ya que las entadas no varian, debo variar las entradas para condiciones muy similares
        --ver criterio


        --- EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '||XOR_SIM(binary_val,rexp_value)||', '||id_row||')';


        IF attr_erased <= 10 THEN
            IF attr_counter(attr_erased) = 1 THEN
                skip_vpk := 1;
            ELSE
                skip_vpk := 0;
            END IF;
        ELSE
            skip_vpk := 0;
        END IF;




        IF skip_vpk = 1 THEN
            --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', null, '||id_row||')';
            EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', null, '||id_row||')';
        ELSE
            --EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP'', '||XOR_SIM(binary_val,rexp_value)||', '||id_row||')';
            EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''',''LLP_RESP'', '||XOR_SIM(binary_val,rexp_value)||', '||id_row||')';


        END IF;
       skip_vpk := 0;

       -- dbms_output.put_line(BINARY_CHAR_TO_INTEGER(binary_val));
       -- tuples := tuples + 1;
       -- dbms_output.put_line(tuples);

       avg_value := 0;





        FOR mov_ind IN 1..10 LOOP
            final_counter(mov_ind) := final_counter(mov_ind) + attr_counter(mov_ind);
        END LOOP;

       -- END IF;
    END LOOP;

   -- dbms_output.put_line(tuples);

   FOR ww IN 1..10 LOOP
            dbms_output.put_line(final_counter(ww));
   END LOOP;


    dbms_output.put_line('CONTADOR');
    FOR i IN 1..10 LOOP
            dbms_output.put_line(row_counter(i));
    END LOOP;

    CLOSE id_cursor;  
END SCHEME_2018;

/
--------------------------------------------------------
--  DDL for Procedure SIMULATE_RESP
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."SIMULATE_RESP" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MIN_VAL IN INT, MAX_VAL IN INT) IS 
  id_cursor sys_refcursor;
  attr_val FLOAT(126);
  id_row INT;

BEGIN
  OPEN id_cursor FOR 'SELECT ID AS IDENT FROM '||RELATION||' ORDER BY ID';

  LOOP
    FETCH id_cursor INTO id_row;
    EXIT WHEN id_cursor%NOTFOUND;

    SELECT round(dbms_random.value(MIN_VAL,MAX_VAL)) INTO attr_val from dual;
    EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT('''||RELATION||''','''||ATTR_NAME||''', '||attr_val||', '||id_row||')';
  END LOOP;

  CLOSE id_cursor;

END SIMULATE_RESP;

/
--------------------------------------------------------
--  DDL for Procedure TEST1
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."TEST1" IS 
--cant integer;
BEGIN

    DBMS_OUTPUT.PUT_LINE('Hello World!');
   -- SELECT COUNT(*) INTO cant FROM covertype;
END TEST1;

/
--------------------------------------------------------
--  DDL for Procedure UPATE_COVER_K_OURSCHEME
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."UPATE_COVER_K_OURSCHEME" (ATTR_TO IN VARCHAR2, EXCLUSIVES IN INT) IS
    id_cursor sys_refcursor;
    group_size INT;
    vpk_value INT;

BEGIN

    IF EXCLUSIVES = 0 THEN
        EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT(''covertype_k'','''||ATTR_TO||''', null, 0)';
        OPEN id_cursor FOR 'SELECT COUNT(*) AS AMOUNT_GROUP, LLP AS VPK_VALUE FROM COVERTYPE_A GROUP BY LLP HAVING COUNT(*)>1 ORDER BY LLP';
        LOOP
            FETCH id_cursor INTO group_size, vpk_value;
            EXIT WHEN id_cursor%NOTFOUND;
            EXECUTE IMMEDIATE 'UPDATE covertype_k SET '||ATTR_TO||'=:1 WHERE vpk_value =:2' USING group_size, vpk_value;
        END LOOP;
        CLOSE id_cursor;
   ELSE
        EXECUTE IMMEDIATE 'CALL UPDATE_ATTR_AT(''covertype_x'','''||ATTR_TO||''', null, 0)';
        OPEN id_cursor FOR 'SELECT COUNT(*) AS AMOUNT_GROUP, LLP AS VPK_VALUE FROM COVERTYPE_A GROUP BY LLP HAVING COUNT(*)=1 ORDER BY LLP';
        LOOP
            FETCH id_cursor INTO group_size, vpk_value;
            EXIT WHEN id_cursor%NOTFOUND;
            EXECUTE IMMEDIATE 'UPDATE covertype_x SET '||ATTR_TO||'=:1 WHERE vpk_value =:2' USING group_size, vpk_value;
        END LOOP;
        CLOSE id_cursor;
   END IF;

END UPATE_COVER_K_OURSCHEME;

/
--------------------------------------------------------
--  DDL for Procedure UPDATE_ATTR_AT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."UPDATE_ATTR_AT" ( RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, ATTR_VALUE IN INT, TUPLE_ID IN NUMBER ) IS
BEGIN
  IF TUPLE_ID > 0 THEN
    EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1 WHERE id =:2' USING ATTR_VALUE, TUPLE_ID;
  ELSE
    EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1' USING ATTR_VALUE;
  END IF;
END UPDATE_ATTR_AT;

/
--------------------------------------------------------
--  DDL for Procedure UPDATE_ATTR_ATII
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."UPDATE_ATTR_ATII" ( RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, ATTR_VALUE IN INT, TUPLE_ID IN NUMBER ) IS
BEGIN
  IF TUPLE_ID > 0 THEN
    EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1 WHERE id =:2' USING ATTR_VALUE, TUPLE_ID;
  ELSE
    EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1' USING ATTR_VALUE;
  END IF;
END UPDATE_ATTR_ATII;

/
--------------------------------------------------------
--  DDL for Procedure UPDATE_ATTR_ATIII
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."UPDATE_ATTR_ATIII" ( RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, ATTR_VALUE IN INT, TUPLE_ID IN NUMBER ) IS
BEGIN
  IF TUPLE_ID > 0 THEN
    EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1 WHERE id =:2' USING ATTR_VALUE, TUPLE_ID;
  ELSE
    EXECUTE IMMEDIATE 'UPDATE '||RELATION|| ' SET '||ATTR_NAME||'=:1' USING ATTR_VALUE;
  END IF;
END UPDATE_ATTR_ATIII;

/
--------------------------------------------------------
--  DDL for Procedure UPDATE_CHD_ATTR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."UPDATE_CHD_ATTR" (ATTRIBUTE_SEL IN VARCHAR2)IS
BEGIN
  --UPDATE COVERTYPE_X SET ORIGINAL_ATTR = ATTRIBUTE_SEL;
  --UPDATE COVERTYPE_X SET CHANGED_ATTR = ATTRIBUTE_SEL;

  EXECUTE IMMEDIATE 'UPDATE COVERTYPE_X SET ORIGINAL_ATTR = '||ATTRIBUTE_SEL;
  EXECUTE IMMEDIATE 'UPDATE COVERTYPE_X SET CHANGED_ATTR = '||ATTRIBUTE_SEL;

 -- EXECUTE IMMEDIATE 'DELETE FROM '||RELATION||' WHERE ID = '||IDS;

END UPDATE_CHD_ATTR;

/
--------------------------------------------------------
--  DDL for Procedure UPDATE_CONF
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."UPDATE_CONF" (SK IN VARCHAR2, TF IN INT ) IS
BEGIN
    EXECUTE IMMEDIATE 'UPDATE COVERTYPE_A SET VPK_PERS = CREATE_VPK(LLP,'''||SK||'''), 
    CONS_PERS =  MOD(CREATE_VPK(LLP,'''||SK||'''),'||TF||'),
    SEED_PERS =  MOD(CREATE_VPK(LLP,'''||SK||'''),'||TF||'+1)';
END UPDATE_CONF;

/
