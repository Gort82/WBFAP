DELETE FROM COVERTYPE_A;
COMMIT;
DROP SEQUENCE ID_SEQ;
CREATE SEQUENCE ID_SEQ INCREMENT BY 1 START WITH 1 MAXVALUE 99999999999999999999999 MINVALUE 1 CYCLE CACHE 20 ORDER;

-- upload content from the Forest Cover Type dataset (see paper "Relational data watermarking resilience to brute force attacks inuntrusted environments")

UPDATE COVERTYPE_A SET LLP = ID;
COMMIT;