--------------------------------------------------------
--  DDL for Function GENERATE_MEAN
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GENERATE_MEAN" (VALUE_LIST IN NUMBER_ARRAY) RETURN INT AS 
    mean_value FLOAT;
BEGIN
    FOR i IN 0..VALUE_LIST.COUNT LOOP
        mean_value := mean_value + VALUE_LIST(i);                
    END LOOP;
    mean_value := mean_value/VALUE_LIST.COUNT;
    RETURN mean_value;
END GENERATE_MEAN;



/
--------------------------------------------------------
--  DDL for Function GET_ATTR_GENSTAT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTR_GENSTAT" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT AVG('||ATTR_NAME ||') AS MEAN_ATTR, STDDEV('||ATTR_NAME ||') AS STD_ATTR FROM '||RELATION;
    RETURN inf_cursor;
END GET_ATTR_GENSTAT;



/
--------------------------------------------------------
--  DDL for Function BITOR
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."BITOR" (x In Number, y In Number)
    RETURN NUMBER DETERMINISTIC
  Is
  Begin
    Return x - bitand(x, y) + y;




  End bitor;



/
--------------------------------------------------------
--  DDL for Function GET_ATTRSK_BEH
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTRSK_BEH" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT,PRIV_KEY IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT COUNT(COUNT(*)) AS HIST_BEAN, 
                                AVG(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS AVG_DUPLICATED, 
                                MAX(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS MAX_DUPLICATED, 
                                MIN(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS MIN_DUPLICATED 
                         FROM '||RELATION ||' 
                         WHERE LENGTH(num_to_bin('||ATTR_NAME ||')) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 
                         GROUP BY CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')';


    --, AVG('||ATTR_NAME ||') AS MEAN_ATTR, STDDEV('||ATTR_NAME ||') AS STD_ATTR
    RETURN inf_cursor;
END GET_ATTRSK_BEH;



/
--------------------------------------------------------
--  DDL for Function CONFENIS_INFO
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."CONFENIS_INFO" (IMAGE_HEIGHT IN INT, IMAGE_WIDTH IN INT, ATTR_COUNT IN INT, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
    -- CONFENIS 2019
    --UPDATE COVERTYPE_A SET VPK_PERS =  CREATE_VPK(LLP,'82MR'), 
    --       CONS_PERS =  MOD(CREATE_VPK(LLP,'82MR'),20), 
    --       SEED_PERS =  MOD(CREATE_VPK(LLP,'82MR'),21);

     OPEN id_cursor FOR 

    'SELECT LLP, 
            VPK_PERS, 
            CONS_PERS, 
            SEC_PERS,
            M2,
            ORA_HASH(VPK_PERS,'||IMAGE_HEIGHT||',SEED_PERS + 1) AS H, 
            ORA_HASH(VPK_PERS,'||IMAGE_WIDTH||',SEED_PERS + 2) AS W,
            ORA_HASH(VPK_PERS,'||ATTR_COUNT||',SEED_PERS) AS ATTR_POS,  
            ORA_HASH(VPK_PERS,'||MSB_COUNT||',SEED_PERS + 4) AS MSB_POS, 
            ORA_HASH(VPK_PERS,'||LSB_COUNT||',SEED_PERS + 3) AS LSB_POS 
     FROM COVERTYPE_A 
     ORDER BY LLP';

  RETURN id_cursor;
END CONFENIS_INFO;



/
--------------------------------------------------------
--  DDL for Function GET_ATTR_COUNT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTR_COUNT" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_COUNT IN INT) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT COUNT(*) AS COUNTER_ATTRR FROM '||RELATION ||' WHERE LENGTH(num_to_bin('||ATTR_NAME ||')) > '||MSB_COUNT;
    RETURN inf_cursor;
END GET_ATTR_COUNT;



/
--------------------------------------------------------
--  DDL for Function BITXOR
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."BITXOR" (x In Number, y In Number)
    RETURN NUMBER DETERMINISTIC
  Is
  Begin
    Return x - bitand(x, y) + y;




  End bitxor;



/
--------------------------------------------------------
--  DDL for Function GET_VPK_DATA
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_VPK_DATA" (RELATION IN VARCHAR2, MSB_COUNT IN INT, NO_SEGMENTS IN INT, PRIV_KEY IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 
        'SELECT ID, VALUE_VPK, QUARTILE 
         FROM (SELECT ID AS ID, CREATE_VPK(BINARY_CHAR_TO_INTEGER(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                        CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                        CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                        CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                        CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||')),'''||PRIV_KEY||''') AS VALUE_VPK,

                      NTILE('||NO_SEGMENTS||') OVER (ORDER BY CREATE_VPK(BINARY_CHAR_TO_INTEGER(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                                                CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                                                CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                                                CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                                                CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS QUARTILE
               FROM '||RELATION ||' ) TEMP_TABLE
         ORDER BY VALUE_VPK';


    RETURN inf_cursor;
END GET_VPK_DATA;



/
--------------------------------------------------------
--  DDL for Function RTW_CREATE_VPK
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."RTW_CREATE_VPK" (current_id IN INT, SECRET_KEY IN VARCHAR2) RETURN INT AS 
vpk INT;
BEGIN
  SELECT ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => current_id || SECRET_KEY)) AS VPK INTO vpk FROM dual;
  RETURN vpk;
END RTW_CREATE_VPK;



/
--------------------------------------------------------
--  DDL for Function RTW_ATTR_VALUE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."RTW_ATTR_VALUE" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2,TUPLE_ID IN INT) RETURN CLOB AS 
 attr_value CLOB;
BEGIN
  EXECUTE IMMEDIATE 'SELECT '||ATTR_NAME||' FROM '||RELATION||' WHERE id =:1' INTO attr_value USING TUPLE_ID;
  RETURN attr_value;
END RTW_ATTR_VALUE;



/
--------------------------------------------------------
--  DDL for Function RTW_GET_EXT_BCHECK
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."RTW_GET_EXT_BCHECK" (TUPLE_ID IN INT) RETURN CLOB AS 
 attr_value CLOB;
BEGIN
  --EXECUTE IMMEDIATE 'SELECT B_EXT_SK FROM TEX_NEWS WHERE id =:1' INTO attr_value USING TUPLE_ID;
  EXECUTE IMMEDIATE 'SELECT B_EXT_SK FROM TEX_DOCUMENTS WHERE id =:1' INTO attr_value USING TUPLE_ID;
  RETURN attr_value;
END RTW_GET_EXT_BCHECK;


/
--------------------------------------------------------
--  DDL for Function GET_RANDOM_TUPLES
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_RANDOM_TUPLES" (RELATION IN VARCHAR2, NUM_TUPL IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
    OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID FROM (SELECT ID FROM '||RELATION ||' ORDER BY dbms_random.value) WHERE rownum <= '||NUM_TUPL ||' ) SELECT ID FROM aux ORDER BY ID';
  RETURN id_cursor;
END GET_RANDOM_TUPLES;



/
--------------------------------------------------------
--  DDL for Function GET_GENERAL_INFOO
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_GENERAL_INFOO" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2,TUPLES_FRACTION IN INT, VECTOR_SIZE IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
  OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||PRIV_KEY||''') AS VPK FROM '||RELATION ||'), aux2 AS (SELECT id AS IDD, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY FROM aux) SELECT ID, VPK, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, ORA_HASH(VPK,'||VECTOR_SIZE||',SEED_BODY+1) AS P FROM aux, aux2 WHERE ID = IDD  ORDER BY ID';
  RETURN id_cursor;
END GET_GENERAL_INFOO;



/
--------------------------------------------------------
--  DDL for Function GET_SPREAD_ATTR
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_SPREAD_ATTR" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2,MSB_COUNT IN INT, VECTOR_SIZE IN INT, SEED_VALUE IN INT) RETURN sys_refcursor AS 


  id_cursor sys_refcursor;

BEGIN

  OPEN id_cursor FOR 'SELECT MIN(COUNT(CASE ((ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''),'||VECTOR_SIZE||',1) + '||SEED_VALUE||')) 

             WHEN 1 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||'))
             WHEN 2 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||'))                                                     
             WHEN 3 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||'))                                                     
             WHEN 4 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 5 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 6 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||'))                                                     
             WHEN 7 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||'))                                                     
             WHEN 8 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||'))                                                     
             WHEN 9 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||'))                                                     
             WHEN 10 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))                                                     
             END)) AS MIN_VALUE,

             MAX(COUNT(CASE ((ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''),'||VECTOR_SIZE||',1) + '||SEED_VALUE||')) 

             WHEN 1 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||'))
             WHEN 2 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||'))                                                     
             WHEN 3 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||'))                                                     
             WHEN 4 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 5 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 6 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||'))                                                     
             WHEN 7 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||'))                                                     
             WHEN 8 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||'))                                                     
             WHEN 9 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||'))                                                     
             WHEN 10 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))                                                     
             END)) AS MAX_VALUE,

             AVG(COUNT(CASE ((ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''),'||VECTOR_SIZE||',1) + '||SEED_VALUE||')) 

             WHEN 1 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||'))
             WHEN 2 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||'))                                                     
             WHEN 3 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||'))                                                     
             WHEN 4 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 5 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 6 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||'))                                                     
             WHEN 7 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||'))                                                     
             WHEN 8 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||'))                                                     
             WHEN 9 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||'))                                                     
             WHEN 10 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))                                                     
             END)) AS AVG_VALUE,

             COUNT(COUNT(CASE ((ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''),'||VECTOR_SIZE||',1) + '||SEED_VALUE||')) 

             WHEN 1 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||'))
             WHEN 2 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||'))                                                     
             WHEN 3 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||'))                                                     
             WHEN 4 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 5 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 6 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||'))                                                     
             WHEN 7 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||'))                                                     
             WHEN 8 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||'))                                                     
             WHEN 9 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||'))                                                     
             WHEN 10 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))                                                     
             END)) AS TOTAL_VALUE

  FROM '||RELATION||'

  WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||'              AND LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
        LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||'                  AND LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
        LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
        LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||'          AND LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
        LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||'          AND LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT||'


  GROUP BY CASE ((ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''),'||VECTOR_SIZE||',1) + '||SEED_VALUE||')) 

             WHEN 1 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||'))
             WHEN 2 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||'))                                                     
             WHEN 3 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||'))                                                     
             WHEN 4 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 5 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||'))                                                     
             WHEN 6 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||'))                                                     
             WHEN 7 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||'))                                                     
             WHEN 8 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||'))                                                     
             WHEN 9 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||'))                                                     
             WHEN 10 THEN BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))                                                     
             END';






  RETURN id_cursor;
END GET_SPREAD_ATTR;



/
--------------------------------------------------------
--  DDL for Function GET_ESCHEME_PRACT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ESCHEME_PRACT" (RELATION IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT, PRIV_KEY IN VARCHAR2, TUPLE_FRACTION IN INT, ATTR_SIZE IN INT) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT COUNT(COUNT(*)) AS TOT_VALUE, MAX(ALL_RES) AS MAX_VALUE, MIN(ALL_RES) AS MIN_VALULE, AVG(ALL_RES) AS AVG_VALUE
      FROM (SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0

        UNION ALL

      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0

      UNION ALL

      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0

      UNION ALL


      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0





      UNION ALL

      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0





      UNION ALL

      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0




      UNION ALL



      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0




      UNION ALL


      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0


      UNION ALL


      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0



      UNION ALL

      SELECT ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE (LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT ||'+'||LSB_COUNT||') AND 
            MOD(ORA_HASH(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')),'||TUPLE_FRACTION||'*'||ATTR_SIZE||')=0)


GROUP BY ALL_RES';




    RETURN inf_cursor;
END GET_ESCHEME_PRACT;



/
--------------------------------------------------------
--  DDL for Function NUM_TO_BIN
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."NUM_TO_BIN" ( i_num IN NUMBER )
    RETURN VARCHAR2 IS
       --l_Num      PLS_INTEGER;
       l_Num      NUMBER;
       l_bit      PLS_INTEGER;
       l_binary   VARCHAR2(128);
    BEGIN
       --
       l_num := i_num;
      --
      WHILE l_num > 1 LOOP
         l_bit := MOD(l_num,2);
         l_binary := TO_CHAR(l_bit)||l_binary;
         l_num := FLOOR(l_num / 2);
      END LOOP;
      --
      IF l_num = 1 THEN
          l_binary := '1'||l_binary;
      END IF;
      --
      RETURN l_binary;
      --
   END num_to_bin;



/
--------------------------------------------------------
--  DDL for Function GET_GENERAL_INFOOOO
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_GENERAL_INFOOOO" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2,TUPLES_FRACTION IN INT, IMAGE_HEIGHT IN INT, IMAGE_WIDTH IN INT, IMAGE_BAND IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
  --OPEN id_cursor FOR 'SELECT id, CREATE_VPK(id,'''||PRIV_KEY||''') AS vpk, MOD(CREATE_VPK(id,'''||PRIV_KEY||'''),'||TUPLES_FRACTION||')AS cons_fact FROM '||RELATION ||' ORDER BY id';


  --OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||PRIV_KEY||''') AS VPK FROM '||RELATION ||') SELECT ID, VPK, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY, ORA_HASH(VPK,'||IMAGE_HEIGHT||',SEED_BODY+1) AS H, ORA_HASH(VPK,'||IMAGE_WIDTH||',SEED_BODY+2) AS W FROM aux ORDER BY ID';

  OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||PRIV_KEY||''') AS VPK FROM '||RELATION ||'), aux2 AS (SELECT id AS IDD, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY FROM aux) SELECT ID, VPK, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, ORA_HASH(VPK,'||IMAGE_HEIGHT||',SEED_BODY+1) AS H, ORA_HASH(VPK,'||IMAGE_WIDTH||',SEED_BODY+2) AS W, ORA_HASH(VPK,'||IMAGE_BAND||',SEED_BODY+3) AS B FROM aux, aux2 WHERE ID = IDD  ORDER BY ID';


  RETURN id_cursor;
END GET_GENERAL_INFOOOO;



/
--------------------------------------------------------
--  DDL for Function GET_MSB_HIST
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_MSB_HIST" (RELATION IN VARCHAR2, MSB_COUNT IN INT, EXCL_TUPLE IN INT) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
IF (EXCL_TUPLE = 1) THEN
    OPEN inf_cursor FOR 'SELECT COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))) AS COUNT_DUPLICATED, 

             BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')) AS VALUE_DUPLICATED 

             FROM '||RELATION ||'

             WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT||' 

            GROUP BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))

             ORDER BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))';

        ELSE
          OPEN inf_cursor FOR 'SELECT COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))) AS COUNT_DUPLICATED, 

             BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')) AS VALUE_DUPLICATED

             FROM '||RELATION ||'

             WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT||' 

            GROUP BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))

             ORDER BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))';

              END IF;


    RETURN inf_cursor;
END GET_MSB_HIST;



/
--------------------------------------------------------
--  DDL for Function GET_ATTR_STAT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTR_STAT" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT AVG('||ATTR_NAME ||') AS MEAN_ATTR, 
                                STDDEV('||ATTR_NAME ||') AS STD_ATTR 
                         FROM '||RELATION ||' 
                         WHERE LENGTH(num_to_bin('||ATTR_NAME ||')) >= '||MSB_COUNT ||'+'||LSB_COUNT;
    RETURN inf_cursor;
END GET_ATTR_STAT;



/
--------------------------------------------------------
--  DDL for Function GET_VPK_HIST
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_VPK_HIST" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||'))) AS VPK_AMOUNT, BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')) AS VPK_VALUE FROM '||RELATION ||' WHERE LENGTH(num_to_bin('||ATTR_NAME ||')) >= '||MSB_COUNT ||'+'||LSB_COUNT||' GROUP BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')) ORDER BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||'))';
    RETURN inf_cursor;
END GET_VPK_HIST;



/
--------------------------------------------------------
--  DDL for Function GET_NO_TUPLES
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_NO_TUPLES" (RELATION IN VARCHAR2) RETURN INT AS 
  row_counter INT;
BEGIN
  EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM '||RELATION INTO row_counter;
  RETURN row_counter;
END GET_NO_TUPLES;



/
--------------------------------------------------------
--  DDL for Function GET_ESCHEME_BRUTE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ESCHEME_BRUTE" (RELATION IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT COUNT(COUNT(*)) AS TOT_VALUE, MAX(COUNT(ALL_RES)) AS MAX_VALUE, MIN(COUNT(ALL_RES)) AS MIN_VALULE, AVG(COUNT(ALL_RES)) AS AVG_VALUE
      FROM (SELECT BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

        UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

      UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

      UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

      UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

      UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

      UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

      UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

      UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' 

      UNION ALL

      SELECT  BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')) AS ALL_RES 
      FROM '||RELATION ||' 
      WHERE LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT ||'+'||LSB_COUNT||')

GROUP BY ALL_RES';




    RETURN inf_cursor;
END GET_ESCHEME_BRUTE;



/
--------------------------------------------------------
--  DDL for Function GET_ATTR_HIST_COUNT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTR_HIST_COUNT" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2) RETURN INT AS 
  rows_counter INT;
BEGIN
    EXECUTE IMMEDIATE 'SELECT COUNT(COUNT(*)) AS COUNTER FROM '||RELATION ||' GROUP BY '||ATTR_NAME INTO rows_counter;
    RETURN rows_counter;
END GET_ATTR_HIST_COUNT;



/
--------------------------------------------------------
--  DDL for Function GET_RELATION_IDS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_RELATION_IDS" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2,TUPLES_FRACTION IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
  OPEN id_cursor FOR 'SELECT id, (SELECT CREATE_VPK(id,'''||PRIV_KEY||''') FROM dual)AS vpk, MOD((SELECT CREATE_VPK(id,'''||PRIV_KEY||''') FROM dual),'||TUPLES_FRACTION||') FROM '||RELATION ||' ORDER BY id';
  RETURN id_cursor;
END GET_RELATION_IDS;



/
--------------------------------------------------------
--  DDL for Function GET_NO_FIELD_OF_TYPE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_NO_FIELD_OF_TYPE" (FIELDTYPE IN VARCHAR2, RELATION IN VARCHAR2) RETURN INT AS 
  field_counter INT;
BEGIN
  EXECUTE IMMEDIATE 'SELECT COUNT (*) FROM user_tab_columns WHERE TABLE_NAME = '''||RELATION||''' AND data_type ='''||FIELDTYPE||'''' INTO field_counter;
  RETURN field_counter;
END GET_NO_FIELD_OF_TYPE;



/
--------------------------------------------------------
--  DDL for Function GET_ATTRS_OF
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTRS_OF" (IDENT IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN

     OPEN id_cursor FOR 'SELECT LLP_EMB,
                                ELEVATION,
                                ASPECT,
                                SLOPE,
                                HOR_DIST_TO_HYDROLOGY,
                                VERT_DIST_TO_HYDROLOGY,
                                HOR_DIST_TO_ROADWAYS,
                                HILLSHADE_9AM,
                                HILLSHADE_NOON,
                                HILLSHADE_3PM,
                                HOR_DIST_TO_FIRE_POINTS
                         FROM COVERTYPE_A WHERE LLP = ' || IDENT;

     RETURN id_cursor;
END GET_ATTRS_OF;



/
--------------------------------------------------------
--  DDL for Function GET_AVG_ATTR
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_AVG_ATTR" (IDENT IN INT) RETURN FLOAT AS 
  avg_attr FLOAT;
BEGIN
  EXECUTE IMMEDIATE 'SELECT (ELEVATION + ASPECT + SLOPE + HOR_DIST_TO_HYDROLOGY + VERT_DIST_TO_HYDROLOGY + HOR_DIST_TO_ROADWAYS + 
       HILLSHADE_9AM + HILLSHADE_NOON + HILLSHADE_3PM + HOR_DIST_TO_FIRE_POINTS)/10 AS PROM FROM COVERTYPE_A WHERE LLP = ' || IDENT  INTO avg_attr;
  RETURN avg_attr;
END GET_AVG_ATTR;



/
--------------------------------------------------------
--  DDL for Function GET_INDEX
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_INDEX" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2, VS_LENGHT IN INT, ATTR_STRD IN VARCHAR2) RETURN sys_refcursor AS 
    id_cursor sys_refcursor;
BEGIN
    OPEN id_cursor FOR 'SELECT MOD(ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => ID ||'''||PRIV_KEY||''')),'||VS_LENGHT||') AS INDX_ELEM, LLP AS PK, '||ATTR_STRD||' AS STORE_VAL
        FROM '||RELATION;

    RETURN id_cursor;
END GET_INDEX;


/
--------------------------------------------------------
--  DDL for Function XOR_SIM
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."XOR_SIM" (FIRST_DECIMAL IN INT, SECOND_DECIMAL IN INT) RETURN INT AS 
    result_value INT;

BEGIN
    result_value := 0;
   -- result_value:= BITOR(BITAND(FIRST_DECIMAL,BITNOT(SECOND_DECIMAL)),BITAND(BITNOT(FIRST_DECIMAL),SECOND_DECIMAL));

    result_value := (FIRST_DECIMAL + SECOND_DECIMAL) - BITAND(FIRST_DECIMAL, SECOND_DECIMAL) * 2; 


    RETURN result_value;
END XOR_SIM;



/
--------------------------------------------------------
--  DDL for Function GET_CANT_ROWS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_CANT_ROWS" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2, TUPLES_FRACTION IN INT) RETURN INT AS
  rows_counter INT;
BEGIN
  EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM '||RELATION||' WHERE MOD(CREATE_VPK(id,'''||PRIV_KEY||'''),'||TUPLES_FRACTION||')=0' INTO rows_counter;
  RETURN rows_counter;
END GET_CANT_ROWS;



/
--------------------------------------------------------
--  DDL for Function GET_RANDOM_IDS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_RANDOM_IDS" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2, NUM_TUPL IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
    OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||PRIV_KEY||''') AS VPK FROM (SELECT ID FROM '||RELATION ||' ORDER BY dbms_random.value) WHERE rownum <= '||NUM_TUPL ||') SELECT ID, VPK FROM aux ORDER BY ID';
  RETURN id_cursor;
END GET_RANDOM_IDS;



/
--------------------------------------------------------
--  DDL for Function RTW_GET_RANDOM_TUPLES
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."RTW_GET_RANDOM_TUPLES" (NUM_TUPL IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
    --OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID FROM (SELECT ID FROM TEX_NEWS ORDER BY dbms_random.value) WHERE rownum <= '||NUM_TUPL ||' ) SELECT ID FROM aux ORDER BY ID';
    OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID FROM (SELECT ID FROM TEX_DOCUMENTS ORDER BY dbms_random.value) WHERE rownum <= '||NUM_TUPL ||' ) SELECT ID FROM aux ORDER BY ID';
    RETURN id_cursor;
END RTW_GET_RANDOM_TUPLES;


/
--------------------------------------------------------
--  DDL for Function TEST2
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."TEST2" (ATTRIBUTES_LIST IN VARCHAR_ARRAY) RETURN INT IS 
--FUNCTION TEST2 RETURN INT IS 
cant INT;
 attr_list_cant INT;
 vpk NUMBER;

    attr_to_mark INT;
BEGIN
    attr_list_cant := ATTRIBUTES_LIST.COUNT;
    --DBMS_OUTPUT.PUT_LINE('Hello World!');
   -- SELECT COUNT(*) INTO cant FROM covertype_X;


    SELECT ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => 1 || '83MR')) INTO vpk FROM dual;
    SELECT MOD(vpk,attr_list_cant)+1 INTO attr_to_mark FROM dual;
    cant:= attr_to_mark;
    RETURN cant;
END;



/
--------------------------------------------------------
--  DDL for Function GENERATE_VALUE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GENERATE_VALUE" (DECIMAL_VALUE IN INT, LSB_RANGE IN INT, PRIV_KEY IN VARCHAR2) RETURN INT AS 
    value_gen INT;
BEGIN
    value_gen := CREATE_VPK(BINARY_CHAR_TO_INTEGER(TO_CHAR(SUBSTR(num_to_bin(DECIMAL_VALUE),1,LENGTH(num_to_bin(DECIMAL_VALUE))-LSB_RANGE))),PRIV_KEY); 
     RETURN value_gen;
END GENERATE_VALUE;



/
--------------------------------------------------------
--  DDL for Function GENERATE_FROM_MSB
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GENERATE_FROM_MSB" (DECIMAL_VALUE IN INT, MSB_RANGE IN INT, PRIV_KEY IN VARCHAR2) RETURN INT AS 
    value_gen INT;
BEGIN
    --value_gen := CREATE_VPK(BINARY_CHAR_TO_INTEGER(TO_CHAR(SUBSTR(num_to_bin(DECIMAL_VALUE),1,LENGTH(num_to_bin(DECIMAL_VALUE))-LSB_RANGE))),PRIV_KEY); 

    value_gen := CREATE_VPK(BINARY_CHAR_TO_INTEGER(TO_CHAR(SUBSTR(num_to_bin(DECIMAL_VALUE),1,MSB_RANGE))),PRIV_KEY); 

     RETURN value_gen;
END GENERATE_FROM_MSB;



/
--------------------------------------------------------
--  DDL for Function RTW_GET_ALLDATA
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."RTW_GET_ALLDATA" (RELATION IN VARCHAR2) RETURN sys_refcursor AS 
  data_cursor sys_refcursor;
BEGIN
  OPEN data_cursor FOR 'SELECT * FROM '||RELATION ;

  RETURN data_cursor;

END RTW_GET_ALLDATA;



/
--------------------------------------------------------
--  DDL for Function GET_GENERAL_INFO
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_GENERAL_INFO" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2, TUPLES_FRACTION IN INT, IMAGE_HEIGHT IN INT, IMAGE_WIDTH IN INT, ATTR_COUNT IN INT, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
  --OPEN id_cursor FOR 'SELECT id, CREATE_VPK(id,'''||PRIV_KEY||''') AS vpk, MOD(CREATE_VPK(id,'''||PRIV_KEY||'''),'||TUPLES_FRACTION||')AS cons_fact FROM '||RELATION ||' ORDER BY id';


  --OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||PRIV_KEY||''') AS VPK FROM '||RELATION ||') SELECT ID, VPK, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY, ORA_HASH(VPK,'||IMAGE_HEIGHT||',SEED_BODY+1) AS H, ORA_HASH(VPK,'||IMAGE_WIDTH||',SEED_BODY+2) AS W FROM aux ORDER BY ID';

    OPEN id_cursor FOR 

    'WITH aux AS (SELECT ID as ID, CREATE_VPK(LLP,'''||PRIV_KEY||''') AS VPK, VPK_II
                  FROM '||RELATION ||'), 

          aux2 AS (SELECT ID AS IDD, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY 
                   FROM aux) 

                   SELECT ID, VPK, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, 
                                   ORA_HASH(VPK,'||IMAGE_HEIGHT||',SEED_BODY+1) AS H, 
                                   ORA_HASH(VPK,'||IMAGE_WIDTH||',SEED_BODY+2) AS W,
                                   ORA_HASH(VPK,'||ATTR_COUNT||',SEED_BODY) AS ATTR_POS,  
                                   ORA_HASH(VPK,'||MSB_COUNT||',SEED_BODY+4) AS MSB_POS, 
                                   ORA_HASH(VPK,'||LSB_COUNT||',SEED_BODY+3) AS LSB_POS, VPK_II AS DIRECT_POS 
                  FROM aux, aux2 
                  WHERE ID = IDD 
                  ORDER BY ID';

  RETURN id_cursor;
END GET_GENERAL_INFO;

--MOD(VPK,'||LSB_COUNT||')



/
--------------------------------------------------------
--  DDL for Function GET_ATTR_OF
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTR_OF" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2,TUPLE_ID IN INT) RETURN NUMBER AS 
 attr_value NUMBER;
BEGIN
  EXECUTE IMMEDIATE 'SELECT '||ATTR_NAME||' FROM '||RELATION||' WHERE id =:1' INTO attr_value USING TUPLE_ID;
  RETURN attr_value;
END GET_ATTR_OF;



/
--------------------------------------------------------
--  DDL for Function GET_GENERAL_INFOOO
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_GENERAL_INFOOO" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2,TUPLES_FRACTION IN INT, IMAGE_HEIGHT IN INT, IMAGE_WIDTH IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
  --OPEN id_cursor FOR 'SELECT id, CREATE_VPK(id,'''||PRIV_KEY||''') AS vpk, MOD(CREATE_VPK(id,'''||PRIV_KEY||'''),'||TUPLES_FRACTION||')AS cons_fact FROM '||RELATION ||' ORDER BY id';


  --OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||PRIV_KEY||''') AS VPK FROM '||RELATION ||') SELECT ID, VPK, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY, ORA_HASH(VPK,'||IMAGE_HEIGHT||',SEED_BODY+1) AS H, ORA_HASH(VPK,'||IMAGE_WIDTH||',SEED_BODY+2) AS W FROM aux ORDER BY ID';

  OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||PRIV_KEY||''') AS VPK FROM '||RELATION ||'), aux2 AS (SELECT id AS IDD, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY FROM aux) SELECT ID, VPK, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, ORA_HASH(VPK,'||IMAGE_HEIGHT||',SEED_BODY+1) AS H, ORA_HASH(VPK,'||IMAGE_WIDTH||',SEED_BODY+2) AS W FROM aux, aux2 WHERE ID = IDD  ORDER BY ID';


  RETURN id_cursor;
END GET_GENERAL_INFOOO;



/
--------------------------------------------------------
--  DDL for Function GET_MSCHEME_GEN
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_MSCHEME_GEN" (RELATION IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT, PRIV_KEY IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS ELEV_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS ASP_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS SLOP_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTH_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS VDTH_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTR_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDIX_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDN_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HSDIII_VALUE,
       CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT ||')),'''||PRIV_KEY||''') AS HDTFP_VALUE

FROM '||RELATION ||' 

WHERE (LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT ||'+'||LSB_COUNT||'               AND LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' ) AND
      (LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT ||'+'||LSB_COUNT||'                   AND LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' ) AND
      (LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT ||'+'||LSB_COUNT||'  AND LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' ) AND
      (LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT ||'+'||LSB_COUNT||'           AND LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' ) AND
      (LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT ||'+'||LSB_COUNT||'           AND LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT ||'+'||LSB_COUNT||' ) ';



    RETURN inf_cursor;
END GET_MSCHEME_GEN;



/
--------------------------------------------------------
--  DDL for Function CREATE_HAV
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."CREATE_HAV" (current_id IN INT, SECRET_KEY IN VARCHAR2, ATTR_VALUE IN FLOAT) RETURN INT AS 
hav INT;
BEGIN
  SELECT ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => current_id || SECRET_KEY || ATTR_VALUE)) AS HAV INTO hav FROM dual;
  RETURN hav;
END CREATE_HAV;



/
--------------------------------------------------------
--  DDL for Function GET_ATTR_POS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTR_POS" (HAV_VALUE IN VARCHAR2, ATTR_FRACTION IN INT, IMAGE_HEIGHT IN INT, IMAGE_WIDTH IN INT, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
  OPEN id_cursor FOR 'SELECT ORA_HASH('||HAV_VALUE||','||IMAGE_HEIGHT||', MOD('||HAV_VALUE||','||ATTR_FRACTION||'+1)+1) AS H,  ORA_HASH('||HAV_VALUE||','||IMAGE_WIDTH||', MOD('||HAV_VALUE||','||ATTR_FRACTION||'+1)+2) AS W, ORA_HASH('||HAV_VALUE||','||MSB_COUNT||', MOD('||HAV_VALUE||','||ATTR_FRACTION||'+1)+4) AS MSB_POS, ORA_HASH('||HAV_VALUE||','||LSB_COUNT||', MOD('||HAV_VALUE||','||ATTR_FRACTION||'+1)+3) AS LSB_POS FROM dual';
  RETURN id_cursor;
END GET_ATTR_POS;



/
--------------------------------------------------------
--  DDL for Function GENERATE_E
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GENERATE_E" ( RELATION IN VARCHAR2, 
                                        MSB_RANGE IN INT, 
                                        LSB_COUNT IN INT, 
                                        CANT_ATTR IN INT,
                                        ATTR_ID IN INT,
                                        PRIV_KEY IN VARCHAR2, 
                                        TUPLES_FRACTION IN INT, 
                                        IMAGE_HEIGHT IN INT, 
                                        IMAGE_WIDTH IN INT) RETURN sys_refcursor AS
                                         
    id_cursor sys_refcursor;
    result_cursor sys_refcursor;
  --  id_row NUMBER;
   -- id_attr NUMBER;
   -- pre_vpk INT;
    attr_collect VARCHAR_ARRAY;
    general_cons INT;

BEGIN
    general_cons := TUPLES_FRACTION * CANT_ATTR;
    --general_cons := TUPLES_FRACTION;
    attr_collect := VARCHAR_ARRAY();
    attr_collect.EXTEND(CANT_ATTR);

    attr_collect(1):= 'ELEVATION';
    attr_collect(2):= 'ASPECT';
    attr_collect(3):= 'SLOPE';
    attr_collect(4):= 'HOR_DIST_TO_HYDROLOGY';
    attr_collect(5):= 'VERT_DIST_TO_HYDROLOGY';
    attr_collect(6):= 'HOR_DIST_TO_ROADWAYS';
    attr_collect(7):= 'HILLSHADE_9AM';
    attr_collect(8):= 'HILLSHADE_NOON';
    attr_collect(9):= 'HILLSHADE_3PM';
    attr_collect(10):= 'HOR_DIST_TO_FIRE_POINTS';

   -- FOR i IN 1..CANT_ATTR LOOP

            OPEN result_cursor FOR   
                    'WITH aux  AS (SELECT ID as ID, '||ATTR_ID||' AS ATTR_ID, CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(NUM_TO_BIN(ABS('||attr_collect(ATTR_ID)||')),1,'||MSB_RANGE||')),'''||PRIV_KEY||''') AS VPK, '||attr_collect(ATTR_ID)||' AS ATTR_VALUE FROM '||RELATION ||'), 
                          aux2 AS (SELECT ID AS IDD, ATTR_ID AS ATTR_IDD, MOD(VPK,'||general_cons||'+1) AS SEED_BODY FROM aux) 

                     SELECT ID, ATTR_ID, VPK, ATTR_VALUE, 
                                              MOD(VPK,'||general_cons||') AS CONS_FACT, 
                                              ORA_HASH(VPK,'||IMAGE_HEIGHT||',SEED_BODY+1) AS H, 
                                              ORA_HASH(VPK,'||IMAGE_WIDTH||',SEED_BODY+2) AS W,
                                              ORA_HASH(VPK,'||MSB_RANGE||',SEED_BODY+4) AS MSB_POS, 
                                              ORA_HASH(VPK,'||LSB_COUNT||',SEED_BODY+3) AS LSB_POS 
                     FROM aux, aux2 
                     WHERE (ID = IDD) AND (ATTR_ID = ATTR_IDD) 
                     ORDER BY ATTR_VALUE';







   -- END LOOP;







  RETURN result_cursor;
END GENERATE_E;



/
--------------------------------------------------------
--  DDL for Function GET_STATISTICS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_STATISTICS" (RELATION IN VARCHAR2) RETURN sys_refcursor AS 
  stat_cursor sys_refcursor;
BEGIN
    OPEN stat_cursor FOR 'SELECT AVG(ELEVATION) AS MEAN_ELEV, VARIANCE(ELEVATION) AS STD_ELEV, 
         AVG(ASPECT) AS MEAN_ASP,     STDDEV(ASPECT) AS STD_ASP, 
         AVG(SLOPE) AS MEAN_SLOPE, STDDEV(SLOPE) AS STD_SLOPE,
         AVG(HOR_DIST_TO_HYDROLOGY) AS MEAN_HDH, STDDEV(HOR_DIST_TO_HYDROLOGY) AS STD_HDH, 
         AVG(VERT_DIST_TO_HYDROLOGY) AS MEAN_VDH, STDDEV(VERT_DIST_TO_HYDROLOGY) AS STD_VDH, 
         AVG(HOR_DIST_TO_ROADWAYS) AS MEAN_RW, STDDEV(HOR_DIST_TO_ROADWAYS) AS STD_RW, 
         AVG(HILLSHADE_9AM) AS MEAN_HSIX, STDDEV(HILLSHADE_9AM) AS STD_HSIX,
         AVG(HILLSHADE_NOON) AS MEAN_HSN, STDDEV(HILLSHADE_NOON) AS STD_HSN, 
         AVG(HILLSHADE_3PM) AS MEAN_HSIII, STDDEV(HILLSHADE_3PM) AS STD_HSIII,
         AVG(HOR_DIST_TO_FIRE_POINTS) AS MEAN_FP, STDDEV(HOR_DIST_TO_FIRE_POINTS) AS STD_FP
       FROM '||RELATION;
  RETURN stat_cursor;
END GET_STATISTICS;



/
--------------------------------------------------------
--  DDL for Function GET_NOEXCL_ATTR
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_NOEXCL_ATTR" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN INT AS 
  total_counter INT;
  considered_counter INT;
BEGIN
  EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM '||RELATION||' WHERE LENGTH(num_to_bin('||ATTR_NAME ||')) >= '||MSB_COUNT ||'+'||LSB_COUNT INTO considered_counter;
  EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM '||RELATION INTO total_counter;

  RETURN total_counter - considered_counter;
END GET_NOEXCL_ATTR;



/
--------------------------------------------------------
--  DDL for Function GET_VALUE_OF_ATTR
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_VALUE_OF_ATTR" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2,TUPLE_ID IN INT) RETURN NUMBER AS 
 attr_value NUMBER;
BEGIN
  EXECUTE IMMEDIATE 'SELECT '||ATTR_NAME||' FROM '||RELATION||' WHERE id =:1' INTO attr_value USING TUPLE_ID;
  RETURN attr_value;
END GET_VALUE_OF_ATTR;



/
--------------------------------------------------------
--  DDL for Function GET_ATTR_BEH
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTR_BEH" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT COUNT(COUNT(*)) AS HIST_BEAN, AVG(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')))) AS AVG_DUPLICATED, MAX(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')))) AS MAX_DUPLICATED, MIN(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')))) AS MIN_DUPLICATED FROM '||RELATION ||' WHERE LENGTH(num_to_bin('||ATTR_NAME ||')) >= '||MSB_COUNT ||'+'||LSB_COUNT||' GROUP BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||'))';


    --, AVG('||ATTR_NAME ||') AS MEAN_ATTR, STDDEV('||ATTR_NAME ||') AS STD_ATTR
    RETURN inf_cursor;
END GET_ATTR_BEH;



/
--------------------------------------------------------
--  DDL for Function GET_MSB_JOIN
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_MSB_JOIN" (RELATION IN VARCHAR2, MSB_COUNT IN INT, EXCL_TUPLE IN INT) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    IF (EXCL_TUPLE = 1) THEN
      OPEN inf_cursor FOR 'SELECT COUNT(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')))) AS COUNT_DUPLICATED,

             MAX(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')))) AS MAX_DUPLICATED,

             MIN(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')))) AS MIN_DUPLICATED,

             AVG(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')))) AS AVG_DUPLICATED

      FROM '||RELATION ||' 

      WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT||'

      GROUP BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))';

    ELSE
      OPEN inf_cursor FOR 'SELECT COUNT(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')))) AS COUNT_DUPLICATED,

             MAX(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')))) AS MAX_DUPLICATED,

             MIN(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')))) AS MIN_DUPLICATED,

             AVG(COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')))) AS AVG_DUPLICATED

      FROM '||RELATION ||' 

      GROUP BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||'))';


    END IF;

    RETURN inf_cursor;
END GET_MSB_JOIN;



/
--------------------------------------------------------
--  DDL for Function GET_ATTR_HIST
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ATTR_HIST" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT '||ATTR_NAME ||' AS ITEM_VAL, COUNT(*) AS ITEMS_AMOUNT FROM '||RELATION ||' GROUP BY '||ATTR_NAME ||' ORDER BY '||ATTR_NAME;

    --OPEN inf_cursor FOR 'SELECT COUNT(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||'))) AS VPK_AMOUNT, BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')) AS VPK_VALUE FROM '||RELATION ||' WHERE LENGTH(num_to_bin('||ATTR_NAME ||')) >= '||MSB_COUNT ||'+'||LSB_COUNT||' GROUP BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||')) ORDER BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||'))';
    RETURN inf_cursor;
END GET_ATTR_HIST;



/
--------------------------------------------------------
--  DDL for Function RTW_GET_EMB_BCHECK
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."RTW_GET_EMB_BCHECK" (TUPLE_ID IN INT) RETURN CLOB AS 
 attr_value CLOB;
BEGIN
  -- EXECUTE IMMEDIATE 'SELECT B_EMB_SK FROM TEX_NEWS WHERE id =:1' INTO attr_value USING TUPLE_ID;
  EXECUTE IMMEDIATE 'SELECT B_EMB_SK FROM TEX_DOCUMENTS WHERE id =:1' INTO attr_value USING TUPLE_ID;
  RETURN attr_value;
END RTW_GET_EMB_BCHECK;


/
--------------------------------------------------------
--  DDL for Function GET_HIST_COUNT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_HIST_COUNT" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_COUNT IN INT, LSB_COUNT IN INT) RETURN INT AS 
  rows_counter INT;
BEGIN
    EXECUTE IMMEDIATE 'SELECT COUNT(COUNT(*)) AS COUNTER FROM '||RELATION ||' WHERE LENGTH(num_to_bin('||ATTR_NAME ||')) >= '||MSB_COUNT ||'+'||LSB_COUNT||' GROUP BY BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin('||ATTR_NAME ||')),1,'||MSB_COUNT||'))' INTO rows_counter;
    RETURN rows_counter;
END GET_HIST_COUNT;



/
--------------------------------------------------------
--  DDL for Function INC_VARIABILITY
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."INC_VARIABILITY" (DECIMAL_VALUE IN VARCHAR2, REDUCT_FAC IN INT) RETURN INT AS 
    value_acum INT;
    value_gen INT;
    inc_step INT;
    j INT;
    num_stored NUMBER_ARRAY;

BEGIN
    value_acum := 0;
    j := 1;
    inc_step := 0;
    num_stored := NUMBER_ARRAY();
    num_stored.EXTEND(LENGTH(DECIMAL_VALUE));

    FOR i IN 1..LENGTH(DECIMAL_VALUE) LOOP
        num_stored(i) := 0;
    END LOOP;

    FOR i IN 1..num_stored.COUNT LOOP
        num_stored(i) := BINARY_CHAR_TO_INTEGER(TO_CHAR(SUBSTR(DECIMAL_VALUE,1,LENGTH(DECIMAL_VALUE)-i+1))) ;
    END LOOP;

    WHILE j <= num_stored.COUNT LOOP
        value_gen := num_stored(j);
        inc_step := MOD(value_gen,REDUCT_FAC)+1;
        value_acum := value_acum + value_gen;         
        j := j+inc_step;
    END LOOP;

    RETURN value_acum;
END INC_VARIABILITY;



/
--------------------------------------------------------
--  DDL for Function BINARY_CHAR_TO_INTEGER
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."BINARY_CHAR_TO_INTEGER" ( string_binary IN VARCHAR2 )
    RETURN NUMBER IS
       new_string_binary VARCHAR2(2000);
       length_string INT;
       final_result NUMBER;
    BEGIN
      length_string:=LENGTH(string_binary);
      new_string_binary:='';
      IF length_string > 0 THEN
        FOR i  IN 1..length_string
          LOOP
          IF i < LENGTH(string_binary) THEN
            new_string_binary := new_string_binary || SUBSTR(string_binary,i,1) ||',';
          ELSE
            new_string_binary := new_string_binary || SUBSTR(string_binary,i,1);
          END IF;
        END LOOP;
      ELSE
        new_string_binary := '0'; 
      END IF;
     EXECUTE IMMEDIATE 'SELECT BIN_TO_NUM('||new_string_binary||') FROM  dual' INTO final_result; 
     RETURN final_result;
 END BINARY_CHAR_TO_INTEGER;



/
--------------------------------------------------------
--  DDL for Function ORA_HASH_UTIL
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."ORA_HASH_UTIL" (VPK IN VARCHAR2, DIM_MEASURE IN INT,PSEED IN INT) RETURN INT AS 
 pos INT;
BEGIN
  SELECT ORA_HASH(VPK,DIM_MEASURE,PSEED) INTO pos FROM dual;
  RETURN pos;
END ORA_HASH_UTIL;



/
--------------------------------------------------------
--  DDL for Function AAAA
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."AAAA" ( RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2, MSB_RANGE IN INT ) RETURN sys_refcursor AS 
    id_cursor sys_refcursor;
   -- id_cursor_row COVERTYPE_RESP%ROWTYPE;
BEGIN
    --OPEN id_cursor FOR 'SELECT ID AS IDENT, BINARY_CHAR_TO_INTEGER(SUBSTR(NUM_TO_BIN('||ATTR_NAME||'),1,'||MSB_RANGE||')) AS NEW_VAL FROM '||RELATION||'where'||ATTR_NAME||' > 0' ;

    OPEN id_cursor FOR 'SELECT ID AS IDENT, BINARY_CHAR_TO_INTEGER(SUBSTR(NUM_TO_BIN('||ATTR_NAME||'),1,'||MSB_RANGE||')) AS NEW_VAL FROM '||RELATION||' WHERE '||ATTR_NAME||' > 0' ;
    --LOOP
       -- FETCH id_cursor INTO id_cursor_row;
       -- EXIT WHEN id_cursor%NOTFOUND;
        --EXECUTE IMMEDIATE 'UPDATE_ATTR_AT ('||RELATION||',''LLP'', id_cursor_row.NEW_VAL, id_cursor_row.IDENT)';
   --  END LOOP;

     return id_cursor; 


END AAAA;



/
--------------------------------------------------------
--  DDL for Function GET_NNEXT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_NNEXT" (LSB_COUNT IN INT, ID_CORE IN NUMBER, CANT_TUPL IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN

     OPEN id_cursor FOR 'SELECT LLP, 
                                VPK_PERS, 
                                CONS_PERS, 
                                SEC_PERS,
                                ORA_HASH(VPK_PERS,'||LSB_COUNT||',SEED_PERS + 3) AS LSB_POS 
                         FROM COVERTYPE_A 
                         WHERE (SEC_PERS > -1) AND (CONS_PERS > 0) AND (LLP > '||ID_CORE||') AND (ROWNUM <= '||CANT_TUPL||')
                         ORDER BY LLP';

     RETURN id_cursor;
END GET_NNEXT;



/
--------------------------------------------------------
--  DDL for Function GET_NPREV
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_NPREV" (LSB_COUNT IN INT, ID_CORE IN NUMBER, CANT_TUPL IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN

     OPEN id_cursor FOR 'SELECT * FROM (SELECT LLP, 
                                               VPK_PERS, 
                                               CONS_PERS, 
                                               SEC_PERS,
                                               ORA_HASH(VPK_PERS,'||LSB_COUNT||',SEED_PERS + 3) AS LSB_POS 
                                        FROM COVERTYPE_A 
                                        WHERE (SEC_PERS > -1) AND (CONS_PERS > 0) AND (LLP < '||ID_CORE||')
                                        ORDER BY LLP DESC)
                         WHERE ROWNUM <= '||CANT_TUPL;



     RETURN id_cursor;
END GET_NPREV;



/
--------------------------------------------------------
--  DDL for Function GET_RANDOM_TUPLES_INQUANTIL
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_RANDOM_TUPLES_INQUANTIL" (RELATION IN VARCHAR2, MIN_QUOTA IN INT, MAX_QUOTA IN INT, MARG_PROT IN INT, LSB_COUNT IN INT, SECRET_KEY IN VARCHAR2, TUPLES_FRACTION IN INT, CONSID_QUANT IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
    --OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||SECRET_KEY||''') AS VPK, ORIGINAL_ATTR, LSB_POS FROM (SELECT ID, VPK, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, ORIGINAL_ATTR, ORA_HASH(VPK,'||LSB_COUNT||', 1) AS LSB_POS FROM '||RELATION ||' ORDER BY dbms_random.value) WHERE rownum <= '||NUM_TUPL ||' AND ORIGINAL_ATTR > ('||MIN_QUOTA ||'+'|| MARG_PROT||') AND ORIGINAL_ATTR < ('||MAX_QUOTA ||'-'|| MARG_PROT||') AND (CONS_FACT = 0)) SELECT ID, ORIGINAL_ATTR, LSB_POS FROM aux ORDER BY ID';

    IF CONSID_QUANT = 1 THEN
    OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||SECRET_KEY||''') AS VPK, ORIGINAL_ATTR FROM '||RELATION ||'), 
                             aux2 AS (SELECT id AS IDD, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY FROM aux) 

                             SELECT ID, VPK, ORIGINAL_ATTR, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, ORA_HASH(VPK,'||LSB_COUNT||',SEED_BODY) AS LSB_POS FROM aux, aux2 
                             WHERE (ID = IDD) AND (ORIGINAL_ATTR > ('||MIN_QUOTA ||'+'|| MARG_PROT||') 
                                              AND ORIGINAL_ATTR < ('||MAX_QUOTA ||'-'|| MARG_PROT||') 
                                              AND (MOD(VPK,'||TUPLES_FRACTION||') = 0))  ORDER BY ID';

   ELSE
          OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||SECRET_KEY||''') AS VPK, ORIGINAL_ATTR FROM '||RELATION ||'), 
                             aux2 AS (SELECT id AS IDD, MOD(VPK,'||TUPLES_FRACTION||'+1) AS SEED_BODY FROM aux) 

                             SELECT ID, VPK, ORIGINAL_ATTR, MOD(VPK,'||TUPLES_FRACTION||') AS CONS_FACT, ORA_HASH(VPK,'||LSB_COUNT||',SEED_BODY) AS LSB_POS FROM aux, aux2 
                             WHERE (ID = IDD) AND (MOD(VPK,'||TUPLES_FRACTION||') = 0)  ORDER BY ID';                                     
   END IF;


    RETURN id_cursor;
END GET_RANDOM_TUPLES_INQUANTIL;



/
--------------------------------------------------------
--  DDL for Function GET_INCL_MATRIX
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_INCL_MATRIX" (RELATION IN VARCHAR2, MSB_COUNT IN INT, PRIV_KEY IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 
        'SELECT ID AS ID, 
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0

                    ELSE 1 
                END AS AT_01,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_02,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_03,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_04,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_05,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_06,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_07,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_08,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_09,
                CASE CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||') 
                    WHEN ''_'' THEN 0
                    ELSE 1 
                END AS AT_10

               FROM '||RELATION ||'
         ORDER BY ID';


    RETURN inf_cursor;
END GET_INCL_MATRIX;



/
--------------------------------------------------------
--  DDL for Function CREATE_VPK
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."CREATE_VPK" (current_id IN INT, SECRET_KEY IN VARCHAR2) RETURN INT AS 
vpk INT;
BEGIN
  SELECT ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => current_id || SECRET_KEY)) AS VPK INTO vpk FROM dual;
  RETURN vpk;
END CREATE_VPK;



/
--------------------------------------------------------
--  DDL for Function RTW_GET_GENINF
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."RTW_GET_GENINF" (RELATION IN VARCHAR2, TUPLES_FRACTION IN INT, IMAGE_HEIGHT IN INT, IMAGE_WIDTH IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN

    OPEN id_cursor FOR 'SELECT ID, VPK, TUPL_FACTOR, ORA_HASH(VPK,'||IMAGE_HEIGHT||',MOD(VPK,'||TUPLES_FRACTION||'+1)+1) AS H, 
                                                     ORA_HASH(VPK,'||IMAGE_WIDTH||', MOD(VPK,'||TUPLES_FRACTION||'+1)+2) AS W
                                   FROM '||RELATION ||' ORDER BY ID';

  RETURN id_cursor;

END RTW_GET_GENINF;



/
--------------------------------------------------------
--  DDL for Function GET_RND_IDS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_RND_IDS" (NUM_TUPL IN INT, ATTR_VAL IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
    OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID FROM (SELECT ID, ORIGINAL_ATTR FROM COVERTYPE_K ORDER BY dbms_random.value) WHERE rownum <= '||NUM_TUPL ||' AND ORIGINAL_ATTR < '||ATTR_VAL ||') SELECT ID FROM aux ORDER BY ID';
  RETURN id_cursor;
END GET_RND_IDS;



/
--------------------------------------------------------
--  DDL for Function BITNOT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."BITNOT" (x IN NUMBER) RETURN NUMBER AS 
BEGIN
    RETURN (0 - x) - 1;
END;



/
--------------------------------------------------------
--  DDL for Function CONSIDER_VALUE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."CONSIDER_VALUE" (BINARY_VALUE IN VARCHAR2, MSB_ROOT IN INT) RETURN VARCHAR2 AS 
binary_string VARCHAR2(400);
BEGIN

      --resultados aplicando la tabla, pero no como salen en el paper
      IF SUBSTR(BINARY_VALUE,ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT),1)='1' THEN
          binary_string := '_';
      ELSE
          binary_string := SUBSTR(BINARY_VALUE,1,CET_MSB_RANGE(BINARY_VALUE,MSB_ROOT));
      END IF;

      --resultados del paper, pero diferentes a la tabla 
      --IF SUBSTR(BINARY_VALUE,2,1)='0' THEN 
      --    IF SUBSTR(BINARY_VALUE,ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT,1))='0' THEN
      --        binary_string := '';
      --    ELSE
      --        binary_string := SUBSTR(BINARY_VALUE,1,CET_MSB_RANGE(BINARY_VALUE,MSB_ROOT));
      --    END IF;
      --ELSE
      --    IF SUBSTR(BINARY_VALUE,ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT,1))='0' THEN
      --        binary_string := SUBSTR(BINARY_VALUE,1,CET_MSB_RANGE(BINARY_VALUE,MSB_ROOT));
      --    ELSE
      --        binary_string := '';
      --    END IF;
      --END IF;

  RETURN binary_string;
END CONSIDER_VALUE;



/
--------------------------------------------------------
--  DDL for Function GET_EXT_SCHEME
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_EXT_SCHEME" (RELATION IN VARCHAR2, MSB_COUNT IN INT, EXCL_TUPLE IN INT,  PRIV_KEY IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    IF (EXCL_TUPLE = 1) THEN
      OPEN inf_cursor FOR 
      'SELECT COUNT(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||'''))) AS COUNT_DUPLICATED,

                MAX(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||'''))) AS MAX_DUPLICATED,

                MIN(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||'''))) AS MIN_DUPLICATED,

                AVG(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||'''))) AS AVG_DUPLICATED

      FROM '||RELATION ||' 

      WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT||'

      GROUP BY CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||''')';

    ELSE
       OPEN inf_cursor FOR 
       'SELECT COUNT(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||'''))) AS COUNT_DUPLICATED,

                MAX(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||'''))) AS MAX_DUPLICATED,

                MIN(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||'''))) AS MIN_DUPLICATED,

                AVG(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||'''))) AS AVG_DUPLICATED

      FROM '||RELATION ||' 

      WHERE LENGTH(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')) > 0

      GROUP BY CREATE_VPK(BINARY_CHAR_TO_INTEGER(REPLACE(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                            CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||'),''_'')),'''||PRIV_KEY||''')';


    END IF;

    RETURN inf_cursor;
END GET_EXT_SCHEME;



/
--------------------------------------------------------
--  DDL for Function GET_VPK_QUANTIL
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_VPK_QUANTIL" (RELATION IN VARCHAR2, MSB_COUNT IN INT, NO_SEGMENTS IN INT, VPK_VALUE IN INT, PRIV_KEY IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 
        'SELECT QUARTILE 
         FROM (SELECT CREATE_VPK(BINARY_CHAR_TO_INTEGER(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                        CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                        CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                        CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                        CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||')),'''||PRIV_KEY||''') AS VALUE_VPK,

                      NTILE('||NO_SEGMENTS||') OVER (ORDER BY CREATE_VPK(BINARY_CHAR_TO_INTEGER(CONSIDER_VALUE(TO_CHAR(num_to_bin(ELEVATION)),'||MSB_COUNT||')              || CONSIDER_VALUE(TO_CHAR(num_to_bin(ASPECT)),'||MSB_COUNT||') ||
                                                                                                CONSIDER_VALUE(TO_CHAR(num_to_bin(SLOPE)),'||MSB_COUNT||')                  || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') ||
                                                                                                CONSIDER_VALUE(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),'||MSB_COUNT||') || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),'||MSB_COUNT||') ||
                                                                                                CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_9AM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_NOON)),'||MSB_COUNT||') ||
                                                                                                CONSIDER_VALUE(TO_CHAR(num_to_bin(HILLSHADE_3PM)),'||MSB_COUNT||')          || CONSIDER_VALUE(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),'||MSB_COUNT||')),'''||PRIV_KEY||''')) AS QUARTILE
               FROM '||RELATION ||' ) TEMP_TABLE

        WHERE VALUE_VPK = '||VPK_VALUE;

    RETURN inf_cursor;
END GET_VPK_QUANTIL;



/
--------------------------------------------------------
--  DDL for Function GET_ALL_ROWS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_ALL_ROWS" (RELATION IN VARCHAR2) RETURN INT AS
  rows_counter INT;
BEGIN
  EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM '||RELATION INTO rows_counter;
  RETURN rows_counter;
END GET_ALL_ROWS;



/
--------------------------------------------------------
--  DDL for Function GET_MSBSK_JOIN
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_MSBSK_JOIN" (RELATION IN VARCHAR2, MSB_COUNT IN INT, EXCL_TUPLE IN INT,  PRIV_KEY IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    IF (EXCL_TUPLE = 1) THEN
      OPEN inf_cursor FOR 'SELECT COUNT(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS COUNT_DUPLICATED,

             MAX(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS MAX_DUPLICATED,

             MIN(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS MIN_DUPLICATED,

             AVG(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS AVG_DUPLICATED

      FROM '||RELATION ||' 

      WHERE LENGTH(num_to_bin(ELEVATION)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(ASPECT)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(SLOPE)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(VERT_DIST_TO_HYDROLOGY)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_ROADWAYS)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_9AM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HILLSHADE_NOON)) >= '||MSB_COUNT||' AND
            LENGTH(num_to_bin(HILLSHADE_3PM)) >= '||MSB_COUNT||' AND LENGTH(num_to_bin(HOR_DIST_TO_FIRE_POINTS)) >= '||MSB_COUNT||'

      GROUP BY CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')';

    ELSE
       OPEN inf_cursor FOR 'SELECT COUNT(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS COUNT_DUPLICATED,

             MAX(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS MAX_DUPLICATED,

             MIN(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS MIN_DUPLICATED,

             AVG(COUNT(CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||'''))) AS AVG_DUPLICATED

      FROM '||RELATION ||' 

      GROUP BY CREATE_VPK(BINARY_CHAR_TO_INTEGER(SUBSTR(TO_CHAR(num_to_bin(ELEVATION)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(ASPECT)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(SLOPE)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(VERT_DIST_TO_HYDROLOGY)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_ROADWAYS)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_9AM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_NOON)),1,'||MSB_COUNT||') ||
             SUBSTR(TO_CHAR(num_to_bin(HILLSHADE_3PM)),1,'||MSB_COUNT||') || SUBSTR(TO_CHAR(num_to_bin(HOR_DIST_TO_FIRE_POINTS)),1,'||MSB_COUNT||')),'''||PRIV_KEY||''')';


    END IF;

    RETURN inf_cursor;
END GET_MSBSK_JOIN;



/
--------------------------------------------------------
--  DDL for Function CET_MSB_RANGE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."CET_MSB_RANGE" (BINARY_VALUE IN VARCHAR2, MSB_ROOT IN INT) RETURN INT AS 
msb_pos INT;
BEGIN
  IF (SUBSTR(BINARY_VALUE,ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT)+1,1)='0') THEN
      IF(SUBSTR(BINARY_VALUE,ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT)-1,1)='0') THEN
         msb_pos := ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT);
      ELSE
         msb_pos := ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT)-1;
      END IF;
  ELSE
     IF(SUBSTR(BINARY_VALUE,ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT)-1,1)='0') THEN
         msb_pos := ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT);
     ELSE
         msb_pos := ROUND(LENGTH(BINARY_VALUE)/MSB_ROOT)+1;
     END IF;
  END IF;
  RETURN msb_pos;
END CET_MSB_RANGE;



/
--------------------------------------------------------
--  DDL for Function GET_QUANTIL_QUOTAS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_QUANTIL_QUOTAS" (RELATION IN VARCHAR2, NO_SEGMENTS IN INT, ATTR_NAME IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 
         'SELECT MIN(ATTR_VAL) AS MIN_VAL, MAX(ATTR_VAL) AS MAX_VAL, ATTR_QUART FROM(SELECT '||ATTR_NAME||' AS ATTR_VAL,
          NTILE('||NO_SEGMENTS||') OVER (ORDER BY '||ATTR_NAME||') AS ATTR_QUART FROM '||RELATION||' ORDER BY '||ATTR_NAME||') TEMP_TABLE
          GROUP BY ATTR_QUART ORDER BY ATTR_QUART';

    RETURN inf_cursor;
END GET_QUANTIL_QUOTAS;



/
--------------------------------------------------------
--  DDL for Function GET_LENGTH_RANGE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_LENGTH_RANGE" (RELATION IN VARCHAR2, ATTR_NAME IN VARCHAR2) RETURN sys_refcursor AS 
  inf_cursor sys_refcursor;
BEGIN
    OPEN inf_cursor FOR 'SELECT MAX(LENGTH(num_to_bin('||ATTR_NAME ||'))) AS MAX_LENGTH, MIN(LENGTH(num_to_bin('||ATTR_NAME ||'))) AS MIN_LENGTH FROM '||RELATION;

    RETURN inf_cursor;
END GET_LENGTH_RANGE;



/
--------------------------------------------------------
--  DDL for Function GET_RANDOM_MARKED_IDS
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."GET_RANDOM_MARKED_IDS" (RELATION IN VARCHAR2, PRIV_KEY IN VARCHAR2, NUM_TUPL IN INT, TUPLES_FRACTION IN INT) RETURN sys_refcursor AS 
  id_cursor sys_refcursor;
BEGIN
    OPEN id_cursor FOR 'WITH aux AS (SELECT id as ID, CREATE_VPK(id,'''||PRIV_KEY||''') AS VPK FROM (SELECT ID FROM '||RELATION ||' ORDER BY dbms_random.value) WHERE rownum <= '||NUM_TUPL ||' AND MOD(CREATE_VPK(id,'''||PRIV_KEY||'''),'||TUPLES_FRACTION||')=0) SELECT ID, VPK FROM aux ORDER BY ID';
  RETURN id_cursor;
END GET_RANDOM_MARKED_IDS;



/
--------------------------------------------------------
--  DDL for Function RTW_GENERATE_AVK
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYSTEM"."RTW_GENERATE_AVK" (SECRET_KEY IN VARCHAR2, VPK_TUPL IN INT, LOCK_STREAM IN INT, TUPL_FR IN INT, IMAGE_HEIGHT IN INT, IMAGE_WIDTH IN INT) RETURN sys_refcursor AS  
apk_info sys_refcursor;
BEGIN 
  OPEN apk_info FOR 'SELECT  ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string =>          ''' || SECRET_KEY || ''' ||' || VPK_TUPL || '||' || LOCK_STREAM ||')) AS AVK,  
                             ORA_HASH(ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => ''' || SECRET_KEY || ''' ||' || VPK_TUPL || '||' || LOCK_STREAM ||')), '|| IMAGE_HEIGHT ||', MOD(ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => ''' || SECRET_KEY || ''' ||' || VPK_TUPL || '||' || LOCK_STREAM ||')),' || TUPL_FR || ' + 1 )+1' || ') AS H, 
                             ORA_HASH(ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => ''' || SECRET_KEY || ''' ||' || VPK_TUPL || '||' || LOCK_STREAM ||')), '|| IMAGE_WIDTH  ||', MOD(ORA_HASH(sys.dbms_obfuscation_toolkit.md5(input_string => ''' || SECRET_KEY || ''' ||' || VPK_TUPL || '||' || LOCK_STREAM ||')),' || TUPL_FR || ' + 1 )+2' || ') AS W 
                       FROM dual';

  RETURN apk_info;
END RTW_GENERATE_AVK;



/
